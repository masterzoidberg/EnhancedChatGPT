export class PromptManager {
    constructor() {
        this.folders = [];
        this.settings = {
            theme: 'system',
            quickAccessEnabled: true,
            overlayEnabled: true,
            keyboardShortcuts: {
                toggleOverlay: "Ctrl+Shift+O",
                toggleQuickAccess: "Ctrl+Shift+A"
            }
        };
        this.loadState();
    }
    async loadState() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['folders', 'settings'], (result) => {
                if (result.folders) {
                    this.folders = result.folders;
                }
                if (result.settings) {
                    this.settings = result.settings;
                }
                resolve();
            });
        });
    }
    async getFolders() {
        await this.loadState();
        return this.folders;
    }
    async getFavoritePrompts() {
        await this.loadState();
        return this.folders
            .flatMap((folder) => folder.prompts)
            .filter((prompt) => prompt.isFavorite);
    }
    async createFolder(name) {
        const newFolder = {
            id: Date.now().toString(),
            name,
            prompts: [],
            createdAt: Date.now(),
            updatedAt: Date.now()
        };
        this.folders.push(newFolder);
        await this.saveFolders();
        return newFolder;
    }
    async updateFolder(folder) {
        const index = this.folders.findIndex((f) => f.id === folder.id);
        if (index !== -1) {
            this.folders[index] = folder;
            await this.saveFolders();
        }
    }
    async deleteFolder(folderId) {
        this.folders = this.folders.filter((folder) => folder.id !== folderId);
        await this.saveFolders();
    }
    async createPrompt(promptData) {
        const newPrompt = {
            id: Date.now().toString(),
            ...promptData,
            createdAt: Date.now(),
            updatedAt: Date.now(),
        };
        const folder = this.folders.find((f) => f.id === promptData.folderId);
        if (folder) {
            folder.prompts.push(newPrompt);
            await this.saveFolders();
        }
        return newPrompt;
    }
    async updatePrompt(prompt) {
        const folder = this.folders.find((f) => f.id === prompt.folderId);
        if (folder) {
            const index = folder.prompts.findIndex((p) => p.id === prompt.id);
            if (index !== -1) {
                folder.prompts[index] = {
                    ...prompt,
                    updatedAt: Date.now(),
                };
                await this.saveFolders();
            }
        }
    }
    async deletePrompt(promptId) {
        for (const folder of this.folders) {
            const index = folder.prompts.findIndex((p) => p.id === promptId);
            if (index !== -1) {
                folder.prompts.splice(index, 1);
                await this.saveFolders();
                break;
            }
        }
    }
    async saveFolders() {
        return new Promise((resolve) => {
            chrome.storage.local.set({ folders: this.folders }, () => {
                resolve();
            });
        });
    }
    getSettings() {
        return this.settings;
    }
    async updateSettings(settings) {
        this.settings = { ...this.settings, ...settings };
        return new Promise((resolve) => {
            chrome.storage.local.set({ settings: this.settings }, () => {
                resolve();
            });
        });
    }
}
