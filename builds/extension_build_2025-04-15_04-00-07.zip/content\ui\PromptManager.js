export class PromptManager {
    constructor() {
        this.folders = [];
        this.loadFolders();
    }
    async loadFolders() {
        try {
            const result = await chrome.storage.local.get('folders');
            this.folders = result.folders || [];
        }
        catch (error) {
            console.error('Error loading folders:', error);
            this.folders = [];
        }
    }
    async getFavoritePrompts() {
        const favoritePrompts = [];
        for (const folder of this.folders) {
            if (folder.prompts) {
                const folderFavorites = folder.prompts.filter(prompt => prompt.isFavorite);
                favoritePrompts.push(...folderFavorites);
            }
        }
        return favoritePrompts;
    }
    async getFolders() {
        return this.folders;
    }
    async createFolder(name) {
        const newFolder = {
            id: Date.now().toString(),
            name,
            prompts: [],
        };
        this.folders.push(newFolder);
        await this.saveFolders();
        return newFolder;
    }
    async updateFolder(folder) {
        const index = this.folders.findIndex(f => f.id === folder.id);
        if (index !== -1) {
            this.folders[index] = folder;
            await this.saveFolders();
        }
    }
    async deleteFolder(folderId) {
        this.folders = this.folders.filter(f => f.id !== folderId);
        await this.saveFolders();
    }
    async createPrompt(promptData) {
        const newPrompt = {
            id: Date.now().toString(),
            ...promptData,
            createdAt: Date.now(),
            updatedAt: Date.now(),
        };
        const folder = this.folders.find(f => f.id === promptData.folderId);
        if (folder) {
            folder.prompts.push(newPrompt);
            await this.saveFolders();
        }
        return newPrompt;
    }
    async updatePrompt(prompt) {
        const folder = this.folders.find(f => f.id === prompt.folderId);
        if (folder) {
            const index = folder.prompts.findIndex(p => p.id === prompt.id);
            if (index !== -1) {
                folder.prompts[index] = {
                    ...prompt,
                    updatedAt: Date.now(),
                };
                await this.saveFolders();
            }
        }
    }
    async deletePrompt(promptId) {
        for (const folder of this.folders) {
            const index = folder.prompts.findIndex(p => p.id === promptId);
            if (index !== -1) {
                folder.prompts.splice(index, 1);
                await this.saveFolders();
                break;
            }
        }
    }
    async saveFolders() {
        try {
            await chrome.storage.local.set({ folders: this.folders });
        }
        catch (error) {
            console.error('Error saving folders:', error);
        }
    }
}
