import React, { useEffect } from 'react';
export const OverlayPanel = ({ isOpen, onClose, children }) => {
    useEffect(() => {
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };
        if (isOpen) {
            document.addEventListener('keydown', handleEscape);
        }
        return () => {
            document.removeEventListener('keydown', handleEscape);
        };
    }, [isOpen, onClose]);
    if (!isOpen)
        return null;
    return (React.createElement(React.Fragment, null,
        React.createElement("div", { id: "chatgpt-enhancer-backdrop", className: "fixed inset-0 bg-black/50 transition-opacity", onClick: onClose }),
        React.createElement("div", { id: "chatgpt-enhancer-overlay", className: "fixed right-0 top-0 h-full w-[var(--overlay-width)] bg-white dark:bg-gray-800 transition-transform duration-300 ease-in-out" },
            React.createElement("div", { className: "p-4" },
                React.createElement("button", { onClick: onClose, className: "absolute right-4 top-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200" }, "\u2715"),
                children))));
};
