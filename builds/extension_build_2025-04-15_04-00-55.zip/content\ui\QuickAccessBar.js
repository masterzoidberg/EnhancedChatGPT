import React, { useEffect, useState } from 'react';
export const QuickAccessBar = ({ promptManager }) => {
    const [favoritePrompts, setFavoritePrompts] = useState([]);
    useEffect(() => {
        const loadFavoritePrompts = async () => {
            try {
                const prompts = await promptManager.getFavoritePrompts();
                setFavoritePrompts(prompts);
            }
            catch (error) {
                console.error('Error loading favorite prompts:', error);
            }
        };
        loadFavoritePrompts();
    }, [promptManager]);
    const handlePromptClick = (prompt) => {
        // TODO: Implement prompt insertion logic
        console.log('Inserting prompt:', prompt);
    };
    return (React.createElement("div", { className: "quick-access-bar" }, favoritePrompts.map((prompt) => (React.createElement("button", { key: prompt.id, className: "prompt-button", onClick: () => handlePromptClick(prompt) }, prompt.title)))));
};
