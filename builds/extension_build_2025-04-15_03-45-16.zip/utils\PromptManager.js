export class PromptManager {
    constructor() {
        this.folders = [];
        this.loadFolders();
    }
    async loadFolders() {
        const result = await chrome.storage.local.get('folders');
        this.folders = result.folders || [];
    }
    getFavoritePrompts() {
        const favoritePrompts = [];
        for (const folder of this.folders) {
            const folderFavorites = folder.prompts.filter(prompt => prompt.isFavorite);
            favoritePrompts.push(...folderFavorites);
        }
        return favoritePrompts;
    }
    async saveFolders() {
        await chrome.storage.local.set({ folders: this.folders });
    }
}
