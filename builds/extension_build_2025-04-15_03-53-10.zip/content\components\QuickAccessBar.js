import React, { useEffect, useState } from 'react';
export const QuickAccessBar = ({ promptManager }) => {
    const [favoritePrompts, setFavoritePrompts] = useState([]);
    useEffect(() => {
        const loadFavoritePrompts = async () => {
            const prompts = await promptManager.getFavoritePrompts();
            setFavoritePrompts(prompts);
        };
        loadFavoritePrompts();
    }, [promptManager]);
    const handlePromptClick = (prompt) => {
        const textarea = document.querySelector('textarea');
        if (textarea) {
            const cursorPosition = textarea.selectionStart;
            const textBefore = textarea.value.substring(0, cursorPosition);
            const textAfter = textarea.value.substring(cursorPosition);
            textarea.value = textBefore + prompt.content + textAfter;
            textarea.focus();
            textarea.selectionStart = textarea.selectionEnd = cursorPosition + prompt.content.length;
        }
    };
    if (favoritePrompts.length === 0)
        return null;
    return (React.createElement("div", { id: "chatgpt-enhancer-quick-access-bar", className: "flex items-center gap-2 overflow-x-auto p-2 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700" }, favoritePrompts.map((prompt) => (React.createElement("button", { key: prompt.id, onClick: () => handlePromptClick(prompt), className: "px-3 py-1 text-sm bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors" }, prompt.title)))));
};
