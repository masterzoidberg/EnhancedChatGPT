import { OverlayPanel } from './components/OverlayPanel';
import { QuickAccessBar } from './components/QuickAccessBar';
import { PromptManager } from './ui/PromptManager';
class ContentScript {
    constructor() {
        this.overlayPanel = null;
        this.quickAccessBar = null;
        this.isInitialized = false;
        this.promptManager = new PromptManager();
    }
    initialize() {
        if (this.isInitialized)
            return;
        try {
            this.overlayPanel = OverlayPanel;
            this.quickAccessBar = QuickAccessBar;
            this.isInitialized = true;
        }
        catch (error) {
            console.error('Failed to initialize content script:', error);
        }
    }
}
// Initialize the content script when the page loads
const contentScript = new ContentScript();
if (document.readyState === 'complete') {
    contentScript.initialize();
}
else {
    window.addEventListener('load', () => contentScript.initialize());
}
