// import { OverlayPanel } from './components/OverlayPanel';
// import { QuickAccessBar } from './components/QuickAccessBar';
// import { PromptManager } from './ui/PromptManager';
import '../assets/index.css';
// Content script initialization
(() => {
    class ContentScript {
        constructor() {
            this.overlayPanel = null;
            this.quickAccessBar = null;
            this.promptManager = null;
            this.isInitialized = false;
            // Initialize components
            this.initialize();
        }
        async initialize() {
            if (this.isInitialized)
                return;
            try {
                // Components will be loaded dynamically
                this.isInitialized = true;
                // Notify background script that content script is ready
                chrome.runtime.sendMessage({ type: 'contentScriptReady' });
            }
            catch (error) {
                console.error('Failed to initialize content script:', error);
            }
        }
    }
    // Initialize the content script when the page loads
    const contentScript = new ContentScript();
})();
