# Project Overview
See [docs/README.md](docs/README.md) for full documentation.
