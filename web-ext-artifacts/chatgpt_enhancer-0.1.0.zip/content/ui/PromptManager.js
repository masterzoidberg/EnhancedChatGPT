// PromptManager.js - Manages prompt folders and prompts in the overlay panel (in-panel editor version)

/**
 * The PromptManager provides a rich prompt management interface with in-panel editor,
 * folder organization, tags, versioning, and import/export capabilities.
 */
class PromptManager {
  constructor(container) {
    this.container = container;
    this.folders = this.loadFolders();
    this.prompts = this.loadPrompts();
    this.activeFolderId = this.folders.length ? this.folders[0].id : null;
    this.render();
  }

  loadFolders() {
    try {
      const saved = localStorage.getItem('chatgpt-enhancer-prompt-folders');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Default folder
    return [{ id: 'default', name: 'General', color: '#60a5fa' }];
  }

  saveFolders() {
    localStorage.setItem('chatgpt-enhancer-prompt-folders', JSON.stringify(this.folders));
  }

  loadPrompts() {
    try {
      const saved = localStorage.getItem('chatgpt-enhancer-prompts');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Default prompts
    return [];
  }

  savePrompts() {
    localStorage.setItem('chatgpt-enhancer-prompts', JSON.stringify(this.prompts));
  }

  render() {
    // Helper to render markdown preview (first 3 lines or 200 chars)
    const renderMarkdownPreview = (md) => {
      if (!md) return '';
      let snippet = md.split('\n').slice(0, 3).join('\n');
      if (snippet.length > 200) snippet = snippet.slice(0, 200) + '...';
      if (window.EasyMDE && window.EasyMDE.prototype && window.EasyMDE.prototype.markdown) {
        return window.EasyMDE.prototype.markdown(snippet);
      }
      return snippet.replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[c]));
    };

    // Search/filter state
    if (typeof this.searchQuery !== 'string') this.searchQuery = '';
    const handleSearchInput = (e) => {
      this.searchQuery = e.target.value;
      this.render();
    };

    // Filtering logic: by title, content, or tags
    const filterPrompts = (prompt) => {
      if (prompt.folderId !== this.activeFolderId) return false;
      if (!this.searchQuery) return true;
      const q = this.searchQuery.toLowerCase();
      const inTitle = prompt.title && prompt.title.toLowerCase().includes(q);
      const inContent = prompt.content && prompt.content.toLowerCase().includes(q);
      const inTags = Array.isArray(prompt.tags) && prompt.tags.some(tag => tag.toLowerCase().includes(q));
      return inTitle || inContent || inTags;
    };

    // In-panel editor/history state
    this.editingPromptIdx = typeof this.editingPromptIdx === 'number' ? this.editingPromptIdx : null;
    this.addingPrompt = !!this.addingPrompt;
    this.showingHistoryForIdx = typeof this.showingHistoryForIdx === 'number' ? this.showingHistoryForIdx : null;

    // Layout: flex row, left = list, right = editor/history if active
    this.container.innerHTML = `
      <div class="flex" style="min-height: 500px;">
        <div class="flex-1 pr-4" style="min-width: 340px; max-width: 420px;">
          <div class="flex items-center mb-2">
            <span class="font-semibold text-gray-700 dark:text-gray-200 mr-2">Folders</span>
            <button id="add-folder-btn" class="ml-auto text-xs px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">+ Folder</button>
            <button id="export-prompts-btn" class="ml-2 text-xs px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600">Export</button>
            <button id="import-prompts-btn" class="ml-2 text-xs px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600">Import</button>
          </div>
          <div id="folders-list" class="flex space-x-2 mb-3 overflow-x-auto">
            ${this.folders.map(f => `
              <button class="folder-btn px-2 py-1 rounded ${this.activeFolderId === f.id ? 'bg-blue-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200'}"
                data-id="${f.id}" data-index="${this.folders.indexOf(f)}" draggable="true" style="background-color:${f.color};">${f.name}</button>
            `).join('')}
          </div>
          <div class="flex items-center mb-2">
            <span class="font-semibold text-gray-700 dark:text-gray-200 mr-2">Prompts</span>
            <button id="add-prompt-btn" class="ml-auto text-xs px-2 py-1 bg-green-500 text-white rounded hover:bg-green-600">+ Prompt</button>
          </div>
          <div class="mb-2">
            <input id="prompt-search-bar" type="text" class="w-full px-2 py-1 border rounded text-sm" placeholder="Search by title, content, or tag..." value="${this.searchQuery.replace(/"/g, '&quot;')}" />
          </div>
          <div id="prompts-list" class="space-y-2">
            ${this.prompts.filter(filterPrompts).map((p, i) => `
              <div class="prompt-item flex items-center justify-between p-2 rounded bg-gray-100 dark:bg-gray-800"
                   data-index="${i}" data-folder-id="${this.activeFolderId}" draggable="true" style="align-items: flex-start;">
                <div style="flex:1; min-width:0;">
                  <span class="prompt-title text-sm font-semibold">${p.title}</span>
                  <div class="prompt-preview text-xs mt-1" style="color:#555; max-width: 400px; overflow-x: auto;"
                    ${window.EasyMDE ? '' : 'title="Preview loads after first edit"'}
                    >${renderMarkdownPreview(p.content)}</div>
                  <div class="prompt-tags mt-1" style="display: flex; flex-wrap: wrap; gap: 4px;">
                    ${(Array.isArray(p.tags) && p.tags.length > 0) ? p.tags.map(tag => `
                      <span class="text-xs px-2 py-0.5 rounded bg-blue-200 text-blue-800" style="background:#dbeafe; color:#1e40af;">${tag}</span>
                    `).join('') : ''}
                  </div>
                </div>
                <div class="ml-2 flex-shrink-0">
                  <button class="insert-prompt-btn text-xs text-blue-500 hover:underline mr-2" title="Insert">Insert</button>
                  <button class="edit-prompt-btn text-xs text-gray-500 hover:underline mr-2" title="Edit">Edit</button>
                  <button class="history-prompt-btn text-xs text-yellow-600 hover:underline mr-2" title="History">History</button>
                  <button class="delete-prompt-btn text-xs text-red-500 hover:underline" title="Delete">&times;</button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="flex-1" id="editor-pane" style="min-width: 340px; max-width: 600px;">
          ${this.addingPrompt ? this.renderEditorPane(null) : ''}
          ${this.editingPromptIdx !== null ? this.renderEditorPane(this.prompts[this.editingPromptIdx], this.editingPromptIdx) : ''}
          ${this.showingHistoryForIdx !== null ? this.renderHistoryPane(this.prompts[this.showingHistoryForIdx], this.showingHistoryForIdx) : ''}
        </div>
      </div>
    `;
    // Attach search input event
    const searchInput = this.container.querySelector('#prompt-search-bar');
    if (searchInput) {
      searchInput.addEventListener('input', handleSearchInput);
    }
    this.addEventListeners();
  }

  // Utility to load EasyMDE from CDN if not already loaded
  loadEasyMDE(callback) {
    if (window.EasyMDE) {
      callback();
      return;
    }
    if (!document.getElementById('easymde-css')) {
      const link = document.createElement('link');
      link.id = 'easymde-css';
      link.rel = 'stylesheet';
      link.href = 'https://cdn.jsdelivr.net/npm/easymde/dist/easymde.min.css';
      document.head.appendChild(link);
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/easymde/dist/easymde.min.js';
    script.onload = () => callback();
    document.body.appendChild(script);
  }

  // In-panel editor pane for add/edit
  renderEditorPane(promptObj, idx) {
    const title = promptObj ? promptObj.title : '';
    const content = promptObj ? promptObj.content : '';
    const tags = Array.isArray(promptObj?.tags) ? promptObj.tags.join(', ') : '';
    const idPrefix = promptObj ? `edit-${idx}` : 'add';
    const versions = promptObj && Array.isArray(promptObj.versions) ? promptObj.versions : [];
    return `
      <div class="bg-white dark:bg-gray-900 rounded shadow p-4" style="margin: 16px 0;">
        <h2 class="font-semibold text-lg mb-2">${promptObj ? 'Edit Prompt' : 'Add Prompt'}</h2>
        <label class="block mb-1 text-sm font-medium">Title</label>
        <input id="${idPrefix}-title" class="w-full mb-3 px-2 py-1 border rounded" value="${title.replace(/"/g, '&quot;')}" />
        <label class="block mb-1 text-sm font-medium">Content (Markdown supported)</label>
        <textarea id="${idPrefix}-content" class="w-full" rows="8">${content.replace(/</g, '&lt;')}</textarea>
        <label class="block mb-1 text-sm font-medium mt-2">Tags (comma-separated)</label>
        <input id="${idPrefix}-tags" class="w-full mb-3 px-2 py-1 border rounded" value="${tags}" placeholder="e.g. brainstorming, code, writing" />
        <div class="flex gap-2 mt-4">
          <button id="${idPrefix}-cancel" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300">Cancel</button>
          <button id="${idPrefix}-save" class="px-3 py-1 rounded bg-blue-500 text-white hover:bg-blue-600">Save</button>
        </div>
        <div class="mt-4">
          <h3 class="font-semibold text-sm mb-1">Live Preview</h3>
          <div id="${idPrefix}-preview" class="border rounded p-2 bg-gray-50 dark:bg-gray-800" style="min-height: 80px;"></div>
        </div>
        ${versions && versions.length > 0 ? `
          <div class="mt-4">
            <h3 class="font-semibold text-sm mb-1">Version History</h3>
            <ul style="max-height: 120px; overflow-y: auto; padding: 0; margin: 0;">
              ${versions.slice().reverse().map((v, i) => `
                <li style="border-bottom: 1px solid #eee; padding: 6px 0;">
                  <div style="font-size: 13px; color: #666;">
                    <b>${v.title}</b>
                    <span style="float:right; font-size:11px; color:#aaa;">
                      ${v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}
                    </span>
                  </div>
                  <pre style="background:#f8f8f8; color:#333; font-size:12px; padding:4px; border-radius:4px; margin:4px 0 6px 0; max-width:400px; overflow-x:auto;">${v.content.replace(/</g, '&lt;')}</pre>
                  <button class="revert-version-btn" data-version-idx="${versions.length - 1 - i}" style="font-size:12px; color:#fff; background:#38a169; border:none; border-radius:4px; padding:2px 8px; cursor:pointer;">Revert</button>
                </li>
              `).join('')}
            </ul>
          </div>
        ` : ''}
      </div>
    `;
  }

  // In-panel history pane
  renderHistoryPane(promptObj, idx) {
    const versions = (promptObj.versions || []).slice().reverse();
    return `
      <div class="bg-white dark:bg-gray-900 rounded shadow p-4" style="margin: 16px 0;">
        <h2 class="font-semibold text-lg mb-2">Prompt History</h2>
        ${versions.length === 0 ? '<div class="text-gray-500">No previous versions.</div>' : `
          <ul style="max-height: 300px; overflow-y: auto; padding: 0; margin: 0;">
            ${versions.map((v, i) => `
              <li style="border-bottom: 1px solid #eee; padding: 10px 0;">
                <div style="font-size: 13px; color: #666;">
                  <b>${v.title}</b>
                  <span style="float:right; font-size:11px; color:#aaa;">
                    ${v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}
                  </span>
                </div>
                <pre style="background:#f8f8f8; color:#333; font-size:12px; padding:6px; border-radius:4px; margin:6px 0 8px 0; max-width:400px; overflow-x:auto;">${v.content.replace(/</g, '&lt;')}</pre>
                <button class="revert-version-btn" data-version-idx="${versions.length - 1 - i}" style="font-size:12px; color:#fff; background:#38a169; border:none; border-radius:4px; padding:3px 10px; cursor:pointer;">Revert to this version</button>
              </li>
            `).join('')}
          </ul>
        `}
        <div class="flex gap-2 mt-4">
          <button id="close-history-btn" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300">Close</button>
        </div>
      </div>
    `;
  }

  addEventListeners() {
    // Folder switching
    this.container.querySelectorAll('.folder-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.activeFolderId = btn.getAttribute('data-id');
        this.render();
      });
    });

    // Export prompts
    const exportBtn = this.container.querySelector('#export-prompts-btn');
    if (exportBtn) {
      exportBtn.onclick = () => this.exportPrompts();
    }

    // Import prompts
    const importBtn = this.container.querySelector('#import-prompts-btn');
    if (importBtn) {
      importBtn.onclick = () => this.importPrompts();
    }

    // Add folder
    this.container.querySelector('#add-folder-btn').onclick = () => {
      const name = prompt('Folder name?');
      if (!name) return;
      const color = prompt('Folder color (hex or CSS color)?', '#60a5fa') || '#60a5fa';
      const id = Date.now().toString();
      this.folders.push({ id, name, color });
      this.saveFolders();
      this.activeFolderId = id;
      this.render();
    };

    // Add prompt (in-panel)
    this.container.querySelector('#add-prompt-btn').onclick = () => {
      this.addingPrompt = true;
      this.editingPromptIdx = null;
      this.showingHistoryForIdx = null;
      this.render();
      this.initEditorPane(null, null);
    };

    // Insert prompt
    this.container.querySelectorAll('.insert-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        const prompt = this.prompts.filter(p => p.folderId === this.activeFolderId)[i];
        this.insertPrompt(prompt.content);
      });
    });

    // Edit prompt (in-panel)
    this.container.querySelectorAll('.edit-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        const promptIdx = this.prompts.findIndex(
          (p, j) => p.folderId === this.activeFolderId && j === i
        );
        this.editingPromptIdx = promptIdx;
        this.addingPrompt = false;
        this.showingHistoryForIdx = null;
        this.render();
        this.initEditorPane(this.prompts[promptIdx], promptIdx);
      });
    });

    // History prompt (in-panel)
    this.container.querySelectorAll('.history-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        const promptIdx = this.prompts.findIndex(
          (p, j) => p.folderId === this.activeFolderId && j === i
        );
        this.showingHistoryForIdx = promptIdx;
        this.editingPromptIdx = null;
        this.addingPrompt = false;
        this.render();
        this.initHistoryPane(this.prompts[promptIdx], promptIdx);
      });
    });

    // Delete prompt
    this.container.querySelectorAll('.delete-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        if (!confirm('Delete this prompt?')) return;
        const idx = this.prompts.findIndex(
          (p, j) => p.folderId === this.activeFolderId && j === i
        );
        if (idx !== -1) {
          this.prompts.splice(idx, 1);
          this.savePrompts();
          this.render();
        }
      });
    });

    // Drag-and-drop for folders
    this.container.querySelectorAll('.folder-btn').forEach((btn, i) => {
      btn.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/folder', JSON.stringify({
          fromIndex: i
        }));
        btn.classList.add('opacity-50');
      });
      btn.addEventListener('dragend', (e) => {
        btn.classList.remove('opacity-50');
      });
      btn.addEventListener('dragover', (e) => {
        e.preventDefault();
        btn.classList.add('ring', 'ring-blue-400');
      });
      btn.addEventListener('dragleave', (e) => {
        btn.classList.remove('ring', 'ring-blue-400');
      });
      btn.addEventListener('drop', (e) => {
        e.preventDefault();
        btn.classList.remove('ring', 'ring-blue-400');
        const data = JSON.parse(e.dataTransfer.getData('text/folder'));
        const fromIndex = data.fromIndex;
        const toIndex = i;
        if (fromIndex === toIndex) return;
        const moved = this.folders.splice(fromIndex, 1)[0];
        this.folders.splice(toIndex, 0, moved);
        this.saveFolders();
        this.activeFolderId = this.folders[toIndex].id;
        this.render();
      });
    });

    // Drag-and-drop for prompts
    this.container.querySelectorAll('.prompt-item').forEach((item, i) => {
      item.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', JSON.stringify({
          fromIndex: i,
          fromFolderId: this.activeFolderId
        }));
        item.classList.add('opacity-50');
      });
      item.addEventListener('dragend', (e) => {
        item.classList.remove('opacity-50');
      });
      item.addEventListener('dragover', (e) => {
        e.preventDefault();
        item.classList.add('ring', 'ring-blue-400');
      });
      item.addEventListener('dragleave', (e) => {
        item.classList.remove('ring', 'ring-blue-400');
      });
      item.addEventListener('drop', (e) => {
        e.preventDefault();
        item.classList.remove('ring', 'ring-blue-400');
        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
        const toIndex = i;
        const toFolderId = this.activeFolderId;
        const fromPrompts = this.prompts.filter(p => p.folderId === data.fromFolderId);
        const prompt = fromPrompts[data.fromIndex];
        if (!prompt) return;
        const globalFromIdx = this.prompts.findIndex(
          (p, idx) => p.folderId === data.fromFolderId && idx === this.prompts.findIndex(
            (pp, j) => pp.folderId === data.fromFolderId && j === data.fromIndex
          )
        );
        if (globalFromIdx === -1) return;
        this.prompts.splice(globalFromIdx, 1);
        prompt.folderId = toFolderId;
        const promptsInTarget = this.prompts.filter(p => p.folderId === toFolderId);
        let globalToIdx = 0;
        let count = 0;
        for (let idx = 0; idx < this.prompts.length; idx++) {
          if (this.prompts[idx].folderId === toFolderId) {
            if (count === toIndex) {
              globalToIdx = idx;
              break;
            }
            count++;
          }
          if (idx === this.prompts.length - 1) {
            globalToIdx = this.prompts.length;
          }
        }
        this.prompts.splice(globalToIdx, 0, prompt);
        this.savePrompts();
        this.render();
      });
    });

    // In-panel editor/history event listeners
    if (this.addingPrompt || this.editingPromptIdx !== null) {
      this.initEditorPane(
        this.editingPromptIdx !== null ? this.prompts[this.editingPromptIdx] : null,
        this.editingPromptIdx
      );
    }
    if (this.showingHistoryForIdx !== null) {
      this.initHistoryPane(this.prompts[this.showingHistoryForIdx], this.showingHistoryForIdx);
    }
  }

  // Initialize EasyMDE and live preview for editor pane
  initEditorPane(promptObj, idx) {
    const idPrefix = promptObj ? `edit-${idx}` : 'add';
    const textarea = this.container.querySelector(`#${idPrefix}-content`);
    const previewDiv = this.container.querySelector(`#${idPrefix}-preview`);
    if (!textarea || !previewDiv) return;
    this.loadEasyMDE(() => {
      if (window.EasyMDE) {
        if (this._easyMDE) {
          this._easyMDE.toTextArea();
          this._easyMDE = null;
        }
        this._easyMDE = new window.EasyMDE({
          element: textarea,
          initialValue: textarea.value,
          autoDownloadFontAwesome: false,
          spellChecker: false,
          status: false,
          minHeight: "120px",
          toolbar: [
            "bold", "italic", "heading", "|",
            "quote", "unordered-list", "ordered-list", "|",
            "code", "link", "table", "|",
            "preview", "side-by-side", "fullscreen"
          ]
        });
        const updatePreview = () => {
          previewDiv.innerHTML = window.EasyMDE.prototype.markdown(this._easyMDE.value());
        };
        this._easyMDE.codemirror.on('change', updatePreview);
        updatePreview();
      }
    });

    // Save/Cancel handlers
    const saveBtn = this.container.querySelector(`#${idPrefix}-save`);
    const cancelBtn = this.container.querySelector(`#${idPrefix}-cancel`);
    if (cancelBtn) {
      cancelBtn.onclick = () => {
        this.addingPrompt = false;
        this.editingPromptIdx = null;
        this.render();
      };
    }
    if (saveBtn) {
      saveBtn.onclick = () => {
        const newTitle = this.container.querySelector(`#${idPrefix}-title`).value.trim();
        const newContent = this._easyMDE ? this._easyMDE.value() : textarea.value;
        const tagsInput = this.container.querySelector(`#${idPrefix}-tags`).value;
        const newTags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
        if (!newTitle || !newContent) {
          alert('Title and content are required.');
          return;
        }
        if (promptObj) {
          if (!promptObj.versions) promptObj.versions = [];
          promptObj.versions.push({
            title: promptObj.title,
            content: promptObj.content,
            tags: Array.isArray(promptObj.tags) ? [...promptObj.tags] : [],
            timestamp: Date.now()
          });
          promptObj.title = newTitle;
          promptObj.content = newContent;
          promptObj.tags = newTags;
        } else {
          this.prompts.push({
            title: newTitle,
            content: newContent,
            tags: newTags,
            folderId: this.activeFolderId,
            versions: []
          });
        }
        this.savePrompts();
        this.addingPrompt = false;
        this.editingPromptIdx = null;
        this.render();
      };
    }
  }
  
  // Initialize history pane event listeners
  initHistoryPane(promptObj, idx) {
    // Set up revert buttons
    this.container.querySelectorAll('.revert-version-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const versionIdx = parseInt(btn.getAttribute('data-version-idx'), 10);
        if (isNaN(versionIdx) || !promptObj.versions || versionIdx >= promptObj.versions.length) return;
        const version = promptObj.versions[versionIdx];
        
        // Create a new version of the current state before reverting
        promptObj.versions.push({
          title: promptObj.title,
          content: promptObj.content,
          tags: Array.isArray(promptObj.tags) ? [...promptObj.tags] : [],
          timestamp: Date.now()
        });
        
        // Revert to the selected version
        promptObj.title = version.title;
        promptObj.content = version.content;
        promptObj.tags = Array.isArray(version.tags) ? [...version.tags] : [];
        
        this.savePrompts();
        this.showingHistoryForIdx = null;
        this.render();
      });
    });
    
    // Close button
    const closeBtn = this.container.querySelector('#close-history-btn');
    if (closeBtn) {
      closeBtn.onclick = () => {
        this.showingHistoryForIdx = null;
        this.render();
      };
    }
  }
  
  // Export prompts to JSON file
  exportPrompts() {
    const data = {
      folders: this.folders,
      prompts: this.prompts
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chatgpt-prompts-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  
  // Import prompts from JSON file
  importPrompts() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);
          if (Array.isArray(data.folders) && Array.isArray(data.prompts)) {
            if (!confirm('This will replace your current folders and prompts. Continue?')) return;
            this.folders = data.folders;
            this.prompts = data.prompts;
            this.saveFolders();
            this.savePrompts();
            this.activeFolderId = this.folders.length ? this.folders[0].id : null;
            this.render();
            alert('Import successful!');
          } else {
            alert('Invalid file format.');
          }
        } catch (err) {
          alert('Error parsing file: ' + err.message);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }
  
  insertPrompt(text) {
    const textarea = document.querySelector('form textarea');
    if (textarea) {
      textarea.value = text;
      textarea.focus();
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
}

// Make the class available globally
try {
  window.PromptManager = PromptManager;
} catch (e) {
  console.error('Failed to export PromptManager to global scope', e);
}