// QuickAccessBar.js - Manages the quick access bar above the input

export class QuickAccessBar {
  constructor(container) {
    this.container = container;
    this.prompts = this.loadPrompts();
    this.render();
  }

  loadPrompts() {
    try {
      const saved = localStorage.getItem('chatgpt-enhancer-quick-prompts');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Default prompts
    return [
      { label: "Explain", text: "Explain" },
      { label: "Summarize", text: "Summarize" },
      { label: "Rewrite", text: "Rewrite" },
      { label: "Translate", text: "Translate" }
    ];
  }

  savePrompts() {
    localStorage.setItem('chatgpt-enhancer-quick-prompts', JSON.stringify(this.prompts));
  }

  render() {
    this.container.innerHTML = `
      <div class="flex items-center space-x-2 p-1 border-b border-gray-300 dark:border-gray-700 overflow-x-auto">
        <span class="text-xs font-semibold text-gray-500 dark:text-gray-400 mr-2">Quick:</span>
        ${this.prompts.map((p, i) => `
          <button class="quick-prompt-btn text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600 flex items-center" data-index="${i}">
            ${p.label}
            <span class="ml-1 text-gray-400 hover:text-red-500 cursor-pointer remove-quick-prompt" title="Remove">&times;</span>
          </button>
        `).join('')}
        <button class="add-quick-prompt-btn text-xs px-2 py-1 bg-green-200 dark:bg-green-700 rounded hover:bg-green-300 dark:hover:bg-green-600 text-green-800 dark:text-green-100" title="Add quick prompt">+</button>
      </div>
    `;
    this.addEventListeners();
  }

  addEventListeners() {
    // Insert prompt
    this.container.querySelectorAll('.quick-prompt-btn').forEach(button => {
      button.addEventListener('click', (e) => {
        // Don't insert if remove was clicked
        if (e.target.classList.contains('remove-quick-prompt')) return;
        const idx = button.getAttribute('data-index');
        this.insertPrompt(this.prompts[idx].text);
      });
    });

    // Remove prompt
    this.container.querySelectorAll('.remove-quick-prompt').forEach((span, i) => {
      span.addEventListener('click', (e) => {
        e.stopPropagation();
        this.prompts.splice(i, 1);
        this.savePrompts();
        this.render();
      });
    });

    // Add new prompt
    this.container.querySelector('.add-quick-prompt-btn').addEventListener('click', () => {
      const label = prompt('Quick prompt label?');
      if (!label) return;
      const text = prompt('Prompt text to insert?', label);
      if (!text) return;
      this.prompts.push({ label, text });
      this.savePrompts();
      this.render();
    });
  }

  insertPrompt(text) {
    const textarea = document.querySelector('form textarea');
    if (textarea) {
      textarea.value = text;
      textarea.focus();
      textarea.dispatchEvent(new Event('input', { bubbles: true })); // Trigger input event for ChatGPT
    }
  }
}