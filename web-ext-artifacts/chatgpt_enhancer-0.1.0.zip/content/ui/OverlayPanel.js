// OverlayPanel.js - Manages the tabbed interface inside the overlay

// Import the PromptManager - normally we'd use ES6 import but since this is a Chrome Extension
// with potential CSP issues, we'll rely on the global scope version from contentScript.js
// The actual PromptManager implementation is in content/ui/PromptManager.js

export class OverlayPanel {
  constructor(container) {
    this.container = container;
    this.promptManager = null;
    this.render();
  }

  render() {
    this.container.innerHTML = `
      <div id="chatgpt-enhancer-header" class="flex justify-between items-center p-3 border-b border-gray-300 dark:border-gray-700" style="cursor: move;">
        <h2 class="font-semibold text-gray-800 dark:text-gray-200">ChatGPT Enhancer</h2>
        <button id="chatgpt-enhancer-close-btn" class="text-gray-500 hover:text-gray-800 dark:hover:text-gray-100">&times;</button>
      </div>
      
      <div class="flex border-b border-gray-300 dark:border-gray-700">
        <button data-tab="prompts" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400">Prompts</button>
        <button data-tab="chats" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">Chats</button>
        <button data-tab="gpts" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">GPTs</button>
        <button data-tab="settings" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">Settings</button>
      </div>

      <div id="tab-content" class="p-3">
        <div data-tab-content="prompts" class="tab-pane">
          <div id="prompt-manager-container"></div>
        </div>
        <div data-tab-content="chats" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">Chat organization coming soon...</p>
        </div>
        <div data-tab-content="gpts" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">CustomGPT management coming soon...</p>
        </div>
        <div data-tab-content="settings" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">Settings coming soon...</p>
        </div>
      </div>
    `;

    this.addEventListeners();
  }

  addEventListeners() {
    // Close button
    this.container.querySelector('#chatgpt-enhancer-close-btn').onclick = () => {
      this.container.classList.add('hidden');
    };

    // Tab switching
    const tabButtons = this.container.querySelectorAll('.tab-btn');
    const tabPanes = this.container.querySelectorAll('.tab-pane');

    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        const targetTab = button.dataset.tab;

        // Update button styles
        tabButtons.forEach(btn => {
          btn.classList.remove('text-blue-600', 'dark:text-blue-400', 'border-blue-600', 'dark:border-blue-400');
          btn.classList.add('text-gray-500', 'dark:text-gray-400');
        });
        button.classList.add('text-blue-600', 'dark:text-blue-400', 'border-blue-600', 'dark:border-blue-400');
        button.classList.remove('text-gray-500', 'dark:text-gray-400');

        // Update pane visibility
        tabPanes.forEach(pane => {
          if (pane.dataset.tabContent === targetTab) {
            pane.classList.remove('hidden');
            // Lazy initialize PromptManager when Prompts tab is shown
            if (targetTab === 'prompts' && !this.promptManager) {
              const container = pane.querySelector('#prompt-manager-container');
              this.promptManager = new PromptManager(container);
            }
          } else {
            pane.classList.add('hidden');
          }
        });
      });
    });
  }
}