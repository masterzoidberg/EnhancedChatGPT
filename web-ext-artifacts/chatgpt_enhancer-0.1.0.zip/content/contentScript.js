// contentScript.js - Injects UI into ChatGPT

console.log('ChatGPT Enhancer content script loaded.');

// Wait for ChatGPT page to load fully (one-time)
function waitForElement(selector, callback) {
  const observer = new MutationObserver(() => {
    const el = document.querySelector(selector);
    if (el) {
      observer.disconnect();
      callback(el);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// Inline QuickAccessBar class
class QuickAccessBar {
  constructor(container) {
    this.container = container;
    this.render();
  }

  render() {
    this.container.innerHTML = [
      '<div class="flex items-center space-x-2 p-1 border-b border-gray-300 dark:border-gray-700 overflow-x-auto">',
      '  <span class="text-xs font-semibold text-gray-500 dark:text-gray-400 mr-2">Quick:</span>',
      '  <button class="quick-prompt-btn text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600">Explain</button>',
      '  <button class="quick-prompt-btn text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600">Summarize</button>',
      '  <button class="quick-prompt-btn text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600">Rewrite</button>',
      '  <button class="quick-prompt-btn text-xs px-2 py-1 bg-gray-200 dark:bg-gray-700 rounded hover:bg-gray-300 dark:hover:bg-gray-600">Translate</button>',
      '</div>'
    ].join('\n');

    this.addEventListeners();
  }

  addEventListeners() {
    this.container.querySelectorAll('.quick-prompt-btn').forEach(button => {
      button.addEventListener('click', () => {
        const promptText = button.textContent;
        this.insertPrompt(promptText);
      });
    });
  }

  insertPrompt(text) {
    const textarea = document.querySelector('form textarea');
    if (textarea) {
      textarea.value = text;
      textarea.focus();
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }
}

// Sidebar Manager Class
class SidebarManager {
  constructor() {
    this.observer = new MutationObserver(() => {
      const sidebar = document.querySelector('nav');
      if (sidebar) this.initSidebar();
    });
    this.observeSidebar();
  }

  observeSidebar() {
    this.observer.observe(document.body, { childList: true, subtree: true });
  }

  initSidebar() {
    const existing = document.getElementById('chatgpt-enhancer-folders');
    if (!existing) this.injectFolderSection();
  }

  injectFolderSection() {
    const sidebar = document.querySelector('nav');
    if (!sidebar) return;

    const section = document.createElement('div');
    section.id = 'chatgpt-enhancer-folders';
    section.innerHTML = `
      <div class="border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
        <div class="flex items-center justify-between px-2 mb-2">
          <span class="text-xs font-semibold text-gray-500 dark:text-gray-400">Chat Folders</span>
          <button class="add-folder-btn text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">+</button>
        </div>
        <div class="folders-list space-y-1"></div>
      </div>
    `;
    sidebar.appendChild(section);
  }
}

// Initialize managers
const sidebarManager = new SidebarManager();

// Persistent observer to keep Quick Access Bar injected
const persistentObserver = new MutationObserver(() => {
  const inputBox = document.querySelector('form textarea');
  if (!inputBox) return;

  const quickAccessBarId = 'chatgpt-enhancer-quick-access-bar';
  let quickAccessBarContainer = document.getElementById(quickAccessBarId);

  if (!quickAccessBarContainer) {
    console.log('Injecting Quick Access Bar');
    quickAccessBarContainer = document.createElement('div');
    quickAccessBarContainer.id = quickAccessBarId;
    inputBox.closest('form').parentNode.insertBefore(quickAccessBarContainer, inputBox.closest('form'));
    new QuickAccessBar(quickAccessBarContainer);
  }
});

// Helper function to create and show a custom modal
function showCustomModal(title, fields, onSubmit) {
  const modalId = 'chatgpt-enhancer-custom-modal';
  document.getElementById(modalId)?.remove(); // Remove existing modal

  const modalOverlay = document.createElement('div');
  modalOverlay.id = modalId;
  modalOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50'; // Tailwind classes for overlay

  const modalContent = document.createElement('div');
  modalContent.className = 'bg-white dark:bg-gray-800 p-6 rounded shadow-lg w-96'; // Tailwind for modal box

  modalContent.innerHTML = `<h2 class="text-lg font-semibold mb-4 text-gray-800 dark:text-gray-200">${title}</h2>`;

  const form = document.createElement('form');
  const inputs = {};

  fields.forEach(field => {
    const label = document.createElement('label');
    label.className = 'block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300';
    label.textContent = field.label;
    form.appendChild(label);

    let input;
    if (field.type === 'color') {
      input = document.createElement('input');
      input.type = 'color';
      input.className = 'p-1 h-10 w-full block bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 cursor-pointer rounded-lg disabled:opacity-50 disabled:pointer-events-none'; // Basic color input styling
      input.value = field.defaultValue || '#60a5fa';
    } else { // Default to text input
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'w-full mb-3 px-2 py-1 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600'; // Tailwind for text input
      input.value = field.defaultValue || '';
      if (field.placeholder) input.placeholder = field.placeholder;
    }
    input.id = `modal-input-${field.id}`;
    form.appendChild(input);
    inputs[field.id] = input;
  });

  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'flex justify-end gap-2 mt-4';

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.textContent = 'Cancel';
  cancelButton.className = 'px-3 py-1 rounded bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500';
  cancelButton.onclick = () => modalOverlay.remove();

  const okButton = document.createElement('button');
  okButton.type = 'submit';
  okButton.textContent = 'OK';
  okButton.className = 'px-3 py-1 rounded bg-blue-500 text-white hover:bg-blue-600';

  buttonContainer.appendChild(cancelButton);
  buttonContainer.appendChild(okButton);
  form.appendChild(buttonContainer);

  form.onsubmit = (e) => {
    e.preventDefault();
    const result = {};
    Object.keys(inputs).forEach(key => {
      result[key] = inputs[key].value;
    });
    onSubmit(result);
    modalOverlay.remove();
  };

  modalContent.appendChild(form);
  modalOverlay.appendChild(modalContent);
  document.body.appendChild(modalOverlay);

  // Focus the first input
  const firstInputKey = Object.keys(inputs)[0];
  if (firstInputKey) {
    inputs[firstInputKey].focus();
  }
}


// Inline robust PromptManager class (full implementation)
// Modified PromptManager without Firebase
class PromptManager {
  constructor(container) {
    this.container = container;
    this.db = null;
    this.offlineMode = false;
    this.folders = [];
    this.prompts = [];
    this.activeFolderId = null;
    
    // Initialize with local storage only
    this.offlineMode = true;
    this.loadData().then(() => this.render());
  }

  // Removed initFirebase()

  async getUserId() {
    // Get or create user ID
    let userId = localStorage.getItem('chatgpt-enhancer-userId');
    if (!userId) {
      userId = crypto.randomUUID();
      localStorage.setItem('chatgpt-enhancer-userId', userId);
    }
    return userId;
  }

  async loadData() {
    if (this.offlineMode) {
      this.folders = this.loadFolders();
      this.prompts = this.loadPrompts();
    }
    this.activeFolderId = this.folders.length ? this.folders[0].id : null;
    return Promise.resolve();
  }

  // Removed syncWithFirebase()

  saveFolders() {
    localStorage.setItem('chatgpt-enhancer-prompt-folders', JSON.stringify(this.folders));
    // Removed Firebase sync
  }

  savePrompts() {
    localStorage.setItem('chatgpt-enhancer-prompts', JSON.stringify(this.prompts));
    // Removed Firebase sync
  }

  async exportPrompts() {
    const data = {
      version: 1,
      folders: this.folders,
      prompts: this.prompts,
      exportedAt: new Date().toISOString()
    };
    return JSON.stringify(data, null, 2);
  }

  async importPrompts(jsonData) {
    try {
      const data = JSON.parse(jsonData);
      if (data.version !== 1) throw new Error('Unsupported data version');
      
      this.folders = data.folders || [];
      this.prompts = data.prompts || [];
      this.saveFolders();
      this.savePrompts();
      this.render();
      return true;
    } catch (error) {
      console.error('Import failed:', error);
      return false;
    }
  }

  loadFolders() {
    try {
      const saved = localStorage.getItem('chatgpt-enhancer-prompt-folders');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Default folder
    return [{ id: 'default', name: 'General', color: '#60a5fa' }];
  }

  saveFolders() {
    localStorage.setItem('chatgpt-enhancer-prompt-folders', JSON.stringify(this.folders));
  }

  loadPrompts() {
    try {
      const saved = localStorage.getItem('chatgpt-enhancer-prompts');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Default prompts
    return [];
  }

  savePrompts() {
    localStorage.setItem('chatgpt-enhancer-prompts', JSON.stringify(this.prompts));
  }

  render() {
    // Helper to render markdown preview (first 3 lines or 200 chars)
    const renderMarkdownPreview = (md) => {
      if (!md) return '';
      let snippet = md.split('\n').slice(0, 3).join('\n');
      if (snippet.length > 200) snippet = snippet.slice(0, 200) + '...';
      if (window.EasyMDE && window.EasyMDE.prototype && window.EasyMDE.prototype.markdown) {
        return window.EasyMDE.prototype.markdown(snippet);
      }
      return snippet.replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[c]));
    };

    // Search/filter state
    if (typeof this.searchQuery !== 'string') this.searchQuery = '';
    const handleSearchInput = (e) => {
      this.searchQuery = e.target.value;
      this.render();
    };

    // Filtering logic: by title, content, or tags
    const filterPrompts = (prompt) => {
      if (prompt.folderId !== this.activeFolderId) return false;
      if (!this.searchQuery) return true;
      const q = this.searchQuery.toLowerCase();
      const inTitle = prompt.title && prompt.title.toLowerCase().includes(q);
      const inContent = prompt.content && prompt.content.toLowerCase().includes(q);
      const inTags = Array.isArray(prompt.tags) && prompt.tags.some(tag => tag.toLowerCase().includes(q));
      return inTitle || inContent || inTags;
    };

    // In-panel editor/history state
    this.editingPromptIdx = typeof this.editingPromptIdx === 'number' ? this.editingPromptIdx : null;
    this.addingPrompt = !!this.addingPrompt;
    this.showingHistoryForIdx = typeof this.showingHistoryForIdx === 'number' ? this.showingHistoryForIdx : null;

    // Layout: Two-column layout (Folders Sidebar | Prompts Area)
    this.container.innerHTML = `
      <div class="flex h-full text-gray-800 dark:text-gray-200">
        <!-- Folders Sidebar -->
        <div class="w-1/4 min-w-[200px] max-w-[280px] border-r border-gray-300 dark:border-gray-700 flex flex-col p-2">
          <div class="flex items-center justify-between mb-3">
            <span class="font-semibold text-sm">Folders</span>
            <button id="add-folder-btn" class="text-xs px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600" title="Add Folder">+</button>
          </div>
          <div id="folders-list" class="flex-grow overflow-y-auto space-y-1 pr-1">
            ${this.folders.map((f, idx) => `
              <div class="folder-outer group flex items-center justify-between p-1.5 rounded hover:bg-gray-200 dark:hover:bg-gray-700 cursor-pointer ${this.activeFolderId === f.id ? 'bg-blue-100 dark:bg-blue-900 font-semibold' : ''}"
                   draggable="true" data-idx="${idx}" data-id="${f.id}">
                {/* Folder Button - takes full width until actions appear */}
                <button class="folder-btn flex items-center flex-grow text-left text-sm truncate mr-2" data-id="${f.id}" data-index="${idx}">
                   <span class="w-3 h-3 rounded-full mr-2 flex-shrink-0" style="background-color:${f.color};"></span>
                   <span class="flex-grow">${f.name}</span>
                </button>
                {/* Actions - appear on hover */}
                <div class="folder-actions hidden group-hover:flex items-center space-x-1 ml-1 flex-shrink-0">
                   <button class="rename-folder-btn text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 p-0.5" title="Rename" data-idx="${idx}">✏️</button>
                   <button class="color-folder-btn text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 p-0.5" title="Change color" data-idx="${idx}">🎨</button>
                   {/* Add delete folder button later if needed */}
                </div>
              </div>
            `).join('')}
          </div>
           {/* Footer for Import/Export */}
           <div class="mt-auto pt-2 border-t border-gray-300 dark:border-gray-700 flex gap-2">
             <button id="import-prompts-btn" class="text-xs px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 flex-1">Import</button>
             <button id="export-prompts-btn" class="text-xs px-2 py-1 bg-gray-500 text-white rounded hover:bg-gray-600 flex-1">Export</button>
           </div>
        </div>

        {/* Prompts Area */}
        <div class="flex-1 flex flex-col p-4 bg-gray-50 dark:bg-gray-850"> {/* Slightly different bg */}
          {/* Search and Filter Row */}
          <div class="flex items-center mb-4 gap-2">
             <input id="prompt-search-bar" type="text" class="flex-grow px-3 py-1.5 border border-gray-300 dark:border-gray-600 rounded text-sm dark:bg-gray-700" placeholder="Search prompts..." value="${this.searchQuery.replace(/"/g, '&quot;')}" />
             {/* Add Sort/Filter Dropdowns here later */}
             <button class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 p-1" title="Sort/Filter Options (coming soon)">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4h18M3 8h18M3 12h18M3 16h18M3 20h18" /></svg> {/* Placeholder icon */}
             </button>
          </div>
          {/* Prompt List */}
          <div id="prompts-list" class="flex-grow overflow-y-auto space-y-3 pr-1"> {/* Increased spacing */}
            ${this.prompts.filter(filterPrompts).map((p, i) => `
              <div class="prompt-item flex items-start justify-between p-3 rounded border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 shadow-sm hover:shadow-md transition-shadow duration-150"
                   data-index="${i}" data-folder-id="${this.activeFolderId}" draggable="true">
                {/* Left side: Title, Preview, Tags */}
                <div class="flex-1 min-w-0 mr-4">
                  <span class="prompt-title block text-sm font-semibold mb-1 cursor-pointer hover:underline">${p.title}</span> {/* Make title clickable? */}
                  <div class="prompt-preview text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2"> {/* Limit preview lines */}
                    ${renderMarkdownPreview(p.content)}
                  </div>
                  <div class="prompt-tags flex flex-wrap gap-1">
                    ${(Array.isArray(p.tags) && p.tags.length > 0) ? p.tags.map(tag => `
                      <span class="text-xs px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">${tag}</span>
                    `).join('') : ''}
                  </div>
                </div>
                {/* Right side: Actions */}
                <div class="flex flex-col items-end space-y-1.5 flex-shrink-0">
                  <button class="insert-prompt-btn text-xs px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 w-full text-center" title="Insert">Insert</button>
                  <div class="flex space-x-1.5">
                     <button class="edit-prompt-btn text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 p-0.5" title="Edit">✏️</button>
                     <button class="history-prompt-btn text-xs text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 p-0.5" title="History">🕒</button>
                     <button class="delete-prompt-btn text-xs text-red-500 hover:text-red-700 p-0.5" title="Delete">🗑️</button>
                  </div>
                </div>
              </div>
            `).join('')}
            {/* Empty State Message */}
            ${this.prompts.filter(filterPrompts).length === 0 ? '<p class="text-sm text-gray-500 text-center py-6">No prompts found in this folder or matching search.</p>' : ''}
          </div>
           {/* Add Prompt Button Footer */}
           <div class="mt-4 flex justify-end flex-shrink-0">
             <button id="add-prompt-btn" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 text-sm font-medium">+ Add New Prompt</button>
           </div>
        </div>
      </div>
    `;
    // Attach search input event
    const searchInput = this.container.querySelector('#prompt-search-bar');
    if (searchInput) {
      searchInput.addEventListener('input', handleSearchInput);
    }
    this.addEventListeners();
  }

  // Utility to load EasyMDE from CDN if not already loaded
  loadEasyMDE(callback) {
    if (window.EasyMDE) {
      callback();
      return;
    }
    if (!document.getElementById('easymde-css')) {
      const link = document.createElement('link');
      link.id = 'easymde-css';
      link.rel = 'stylesheet';
      link.href = 'https://cdn.jsdelivr.net/npm/easymde/dist/easymde.min.css';
      document.head.appendChild(link);
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/easymde/dist/easymde.min.js';
    script.onload = () => callback();
    document.body.appendChild(script);
  }

  // In-panel editor pane for add/edit
  renderEditorPane(promptObj, idx) {
    const title = promptObj ? promptObj.title : '';
    const content = promptObj ? promptObj.content : '';
    const tags = Array.isArray(promptObj?.tags) ? promptObj.tags.join(', ') : '';
    const idPrefix = promptObj ? `edit-${idx}` : 'add';
    const versions = promptObj && Array.isArray(promptObj.versions) ? promptObj.versions : [];
    return `
      <div class="bg-white dark:bg-gray-900 rounded shadow p-4" style="margin: 16px 0;">
        <h2 class="font-semibold text-lg mb-2">${promptObj ? 'Edit Prompt' : 'Add Prompt'}</h2>
        <label class="block mb-1 text-sm font-medium">Title</label>
        <input id="${idPrefix}-title" class="w-full mb-3 px-2 py-1 border rounded" value="${title.replace(/"/g, '&quot;')}" />
        <label class="block mb-1 text-sm font-medium">Content (Markdown supported)</label>
        <textarea id="${idPrefix}-content" class="w-full" rows="8">${content.replace(/</g, '&lt;')}</textarea>
        <label class="block mb-1 text-sm font-medium mt-2">Tags (comma-separated)</label>
        <input id="${idPrefix}-tags" class="w-full mb-3 px-2 py-1 border rounded" value="${tags}" placeholder="e.g. brainstorming, code, writing" />
        <div class="flex gap-2 mt-4">
          <button id="${idPrefix}-cancel" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300">Cancel</button>
          <button id="${idPrefix}-save" class="px-3 py-1 rounded bg-blue-500 text-white hover:bg-blue-600">Save</button>
        </div>
        <div class="mt-4">
          <h3 class="font-semibold text-sm mb-1">Live Preview</h3>
          <div id="${idPrefix}-preview" class="border rounded p-2 bg-gray-50 dark:bg-gray-800" style="min-height: 80px;"></div>
        </div>
        ${versions && versions.length > 0 ? `
          <div class="mt-4">
            <h3 class="font-semibold text-sm mb-1">Version History</h3>
            <ul style="max-height: 120px; overflow-y: auto; padding: 0; margin: 0;">
              ${versions.slice().reverse().map((v, i) => `
                <li style="border-bottom: 1px solid #eee; padding: 6px 0;">
                  <div style="font-size: 13px; color: #666;">
                    <b>${v.title}</b>
                    <span style="float:right; font-size:11px; color:#aaa;">
                      ${v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}
                    </span>
                  </div>
                  <pre style="background:#f8f8f8; color:#333; font-size:12px; padding:4px; border-radius:4px; margin:4px 0 6px 0; max-width:400px; overflow-x:auto;">${v.content.replace(/</g, '&lt;')}</pre>
                  <button class="revert-version-btn" data-version-idx="${versions.length - 1 - i}" style="font-size:12px; color:#fff; background:#38a169; border:none; border-radius:4px; padding:2px 8px; cursor:pointer;">Revert</button>
                </li>
              `).join('')}
            </ul>
          </div>
        ` : ''}
      </div>
    `;
  }

  // In-panel history pane
  renderHistoryPane(promptObj, idx) {
    const versions = (promptObj.versions || []).slice().reverse();
    return `
      <div class="bg-white dark:bg-gray-900 rounded shadow p-4" style="margin: 16px 0;">
        <h2 class="font-semibold text-lg mb-2">Prompt History</h2>
        ${versions.length === 0 ? '<div class="text-gray-500">No previous versions.</div>' : `
          <ul style="max-height: 300px; overflow-y: auto; padding: 0; margin: 0;">
            ${versions.map((v, i) => `
              <li style="border-bottom: 1px solid #eee; padding: 10px 0;">
                <div style="font-size: 13px; color: #666;">
                  <b>${v.title}</b>
                  <span style="float:right; font-size:11px; color:#aaa;">
                    ${v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}
                  </span>
                </div>
                <pre style="background:#f8f8f8; color:#333; font-size:12px; padding:6px; border-radius:4px; margin:6px 0 8px 0; max-width:400px; overflow-x:auto;">${v.content.replace(/</g, '&lt;')}</pre>
                <button class="revert-version-btn" data-version-idx="${versions.length - 1 - i}" style="font-size:12px; color:#fff; background:#38a169; border:none; border-radius:4px; padding:3px 10px; cursor:pointer;">Revert to this version</button>
              </li>
            `).join('')}
          </ul>
        `}
        <div class="flex gap-2 mt-4">
          <button id="close-history-btn" class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300">Close</button>
        </div>
      </div>
    `;
  }

  addEventListeners() {
    // Folder switching
    this.container.querySelectorAll('.folder-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        // Prevent switching if clicking rename or color
        if (e.target.closest('.rename-folder-btn') || e.target.closest('.color-folder-btn')) return;
        this.activeFolderId = btn.getAttribute('data-id');
        this.render();
      });
    });

    // Rename folder
    this.container.querySelectorAll('.rename-folder-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'));
        const folder = this.folders[idx];
        showCustomModal('Rename Folder', [{ id: 'name', label: 'Folder Name', defaultValue: folder.name }], (result) => {
          const newName = result.name.trim();
          if (newName) {
            folder.name = newName;
            this.saveFolders();
            this.render();
          }
        });
      });
    });

    // Change folder color
    this.container.querySelectorAll('.color-folder-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.getAttribute('data-idx'));
        const folder = this.folders[idx];
        showCustomModal('Change Folder Color', [{ id: 'color', label: 'Select Color', type: 'color', defaultValue: folder.color || '#60a5fa' }], (result) => {
          folder.color = result.color;
          this.saveFolders();
          this.render();
        });
      });
    });


    // Export prompts
    const exportBtn = this.container.querySelector('#export-prompts-btn');
    if (exportBtn) {
      exportBtn.onclick = () => this.exportPrompts();
    }

    // Import prompts
    const importBtn = this.container.querySelector('#import-prompts-btn');
    if (importBtn) {
      importBtn.onclick = () => this.importPrompts();
    }

    // Add folder
    this.container.querySelector('#add-folder-btn').onclick = () => {
      const name = prompt('Folder name?');
      if (!name) return;
      const color = prompt('Folder color (hex or CSS color)?', '#60a5fa') || '#60a5fa';
      const id = Date.now().toString();
      this.folders.push({ id, name, color });
      this.saveFolders();
      this.activeFolderId = id;
      this.render();
    };

    // Add prompt (using modal)
    this.container.querySelector('#add-prompt-btn').onclick = () => {
      this.showPromptEditorModal(null); // Pass null for adding a new prompt
    };

    // Insert prompt
    this.container.querySelectorAll('.insert-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        const prompt = this.prompts.filter(p => p.folderId === this.activeFolderId)[i];
        this.insertPrompt(prompt.content);
      });
    });

    // Edit prompt (using modal)
    this.container.querySelectorAll('.edit-prompt-btn').forEach(btn => {
       btn.addEventListener('click', (e) => {
         const promptItem = e.target.closest('.prompt-item');
         const index = parseInt(promptItem.dataset.index);
         const promptsInView = this.prompts.filter(this.filterPrompts.bind(this)); // Use bound filter
         const promptObj = promptsInView[index];
         if (promptObj) {
            // Find the actual index in the main prompts array
            const actualIndex = this.prompts.findIndex(p => p === promptObj);
            this.showPromptEditorModal(promptObj, actualIndex);
         } else {
            console.error("Could not find prompt object for editing at index:", index);
         }
       });
    });

    // History prompt (in-panel)
    this.container.querySelectorAll('.history-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        const promptIdx = this.prompts.findIndex(
          (p, j) => p.folderId === this.activeFolderId && j === i
        );
        this.showingHistoryForIdx = promptIdx;
        this.editingPromptIdx = null;
        this.addingPrompt = false;
        this.render();
        this.initHistoryPane(this.prompts[promptIdx], promptIdx);
      });
    });

    // Delete prompt
    this.container.querySelectorAll('.delete-prompt-btn').forEach((btn, i) => {
      btn.addEventListener('click', () => {
        if (!confirm('Delete this prompt?')) return;
        const idx = this.prompts.findIndex(
          (p, j) => p.folderId === this.activeFolderId && j === i
        );
        if (idx !== -1) {
          this.prompts.splice(idx, 1);
          this.savePrompts();
          this.render();
        }
      });
    });

    // Drag-and-drop for folders
    this.container.querySelectorAll('.folder-outer').forEach((folderDiv, i) => {
      folderDiv.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/folder', JSON.stringify({
          fromIndex: i
        }));
        folderDiv.classList.add('opacity-50');
      });
      folderDiv.addEventListener('dragend', (e) => {
        folderDiv.classList.remove('opacity-50');
      });
      folderDiv.addEventListener('dragover', (e) => {
        e.preventDefault();
        folderDiv.classList.add('ring', 'ring-blue-400');
      });
      folderDiv.addEventListener('dragleave', (e) => {
        folderDiv.classList.remove('ring', 'ring-blue-400');
      });
      folderDiv.addEventListener('drop', (e) => {
        e.preventDefault();
        folderDiv.classList.remove('ring', 'ring-blue-400');
        const data = JSON.parse(e.dataTransfer.getData('text/folder'));
        const fromIndex = data.fromIndex;
        const toIndex = i;
        if (fromIndex === toIndex) return;
        const moved = this.folders.splice(fromIndex, 1)[0];
        this.folders.splice(toIndex, 0, moved);
        this.saveFolders();
        this.activeFolderId = this.folders[toIndex].id;
        this.render();
      });
    });

    // Drag-and-drop for prompts
    this.container.querySelectorAll('.prompt-item').forEach((item, i) => {
      item.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', JSON.stringify({
          fromIndex: i,
          fromFolderId: this.activeFolderId
        }));
        item.classList.add('opacity-50');
      });
      item.addEventListener('dragend', (e) => {
        item.classList.remove('opacity-50');
      });
      item.addEventListener('dragover', (e) => {
        e.preventDefault();
        item.classList.add('ring', 'ring-blue-400');
      });
      item.addEventListener('dragleave', (e) => {
        item.classList.remove('ring', 'ring-blue-400');
      });
      item.addEventListener('drop', (e) => {
        e.preventDefault();
        item.classList.remove('ring', 'ring-blue-400');
        const data = JSON.parse(e.dataTransfer.getData('text/plain'));
        const toIndex = i;
        const toFolderId = this.activeFolderId;
        const fromPrompts = this.prompts.filter(p => p.folderId === data.fromFolderId);
        const prompt = fromPrompts[data.fromIndex];
        if (!prompt) return;
        const globalFromIdx = this.prompts.findIndex(
          (p, idx) => p.folderId === data.fromFolderId && idx === this.prompts.findIndex(
            (pp, j) => pp.folderId === data.fromFolderId && j === data.fromIndex
          )
        );
        if (globalFromIdx === -1) return;
        this.prompts.splice(globalFromIdx, 1);
        prompt.folderId = toFolderId;
        const promptsInTarget = this.prompts.filter(p => p.folderId === toFolderId);
        let globalToIdx = 0;
        let count = 0;
        for (let idx = 0; idx < this.prompts.length; idx++) {
          if (this.prompts[idx].folderId === toFolderId) {
            if (count === toIndex) {
              globalToIdx = idx;
              break;
            }
            count++;
          }
          if (idx === this.prompts.length - 1) {
            globalToIdx = this.prompts.length;
          }
        }
        this.prompts.splice(globalToIdx, 0, prompt);
        this.savePrompts();
        this.render();
      });
    });

    // In-panel editor/history event listeners
    if (this.addingPrompt || this.editingPromptIdx !== null) {
      this.initEditorPane(
        this.editingPromptIdx !== null ? this.prompts[this.editingPromptIdx] : null,
        this.editingPromptIdx
      );
    }
    if (this.showingHistoryForIdx !== null) {
      this.initHistoryPane(this.prompts[this.showingHistoryForIdx], this.showingHistoryForIdx);
    }
  }

  // Initialize EasyMDE and live preview for editor pane
  initEditorPane(promptObj, idx) {
    const idPrefix = promptObj ? `edit-${idx}` : 'add';
    const textarea = this.container.querySelector(`#${idPrefix}-content`);
    const previewDiv = this.container.querySelector(`#${idPrefix}-preview`);
    if (!textarea || !previewDiv) return;
    this.loadEasyMDE(() => {
      if (window.EasyMDE) {
        if (this._easyMDE) {
          this._easyMDE.toTextArea();
          this._easyMDE = null;
        }
        this._easyMDE = new window.EasyMDE({
          element: textarea,
          initialValue: textarea.value,
          autoDownloadFontAwesome: false,
          spellChecker: false,
          status: false,
          minHeight: "120px",
          toolbar: [
            "bold", "italic", "heading", "|",
            "quote", "unordered-list", "ordered-list", "|",
            "code", "link", "table", "|",
            "preview", "side-by-side", "fullscreen"
          ]
        });
        const updatePreview = () => {
          previewDiv.innerHTML = window.EasyMDE.prototype.markdown(this._easyMDE.value());
        };
        this._easyMDE.codemirror.on('change', updatePreview);
        updatePreview();
      }
    });

    // Save/Cancel handlers
    const saveBtn = this.container.querySelector(`#${idPrefix}-save`);
    const cancelBtn = this.container.querySelector(`#${idPrefix}-cancel`);
    if (cancelBtn) {
      cancelBtn.onclick = () => {
        this.addingPrompt = false;
        this.editingPromptIdx = null;
        this.render();
      };
    }
    if (saveBtn) {
      saveBtn.onclick = () => {
        const newTitle = this.container.querySelector(`#${idPrefix}-title`).value.trim();
        const newContent = this._easyMDE ? this._easyMDE.value() : textarea.value;
        const tagsInput = this.container.querySelector(`#${idPrefix}-tags`).value;
        const newTags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
        if (!newTitle || !newContent) {
          alert('Title and content are required.');
          return;
        }
        if (promptObj) {
          if (!promptObj.versions) promptObj.versions = [];
          promptObj.versions.push({
            title: promptObj.title,
            content: promptObj.content,
            tags: Array.isArray(promptObj.tags) ? [...promptObj.tags] : [],
            timestamp: Date.now()
          });
          promptObj.title = newTitle;
          promptObj.content = newContent;
          promptObj.tags = newTags;
        } else {
          this.prompts.push({
            title: newTitle,
            content: newContent,
            tags: newTags,
            folderId: this.activeFolderId,
            versions: []
          });
        }
        this.savePrompts();
        this.addingPrompt = false;
        this.editingPromptIdx = null;
        this.render();
      };
    }
  }
  
  // Initialize history pane event listeners
  initHistoryPane(promptObj, idx) {
    // Set up revert buttons
    this.container.querySelectorAll('.revert-version-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const versionIdx = parseInt(btn.getAttribute('data-version-idx'), 10);
        if (isNaN(versionIdx) || !promptObj.versions || versionIdx >= promptObj.versions.length) return;
        const version = promptObj.versions[versionIdx];
        
        // Create a new version of the current state before reverting
        promptObj.versions.push({
          title: promptObj.title,
          content: promptObj.content,
          tags: Array.isArray(promptObj.tags) ? [...promptObj.tags] : [],
          timestamp: Date.now()
        });
        
        // Revert to the selected version
        promptObj.title = version.title;
        promptObj.content = version.content;
        promptObj.tags = Array.isArray(version.tags) ? [...version.tags] : [];
        
        this.savePrompts();
        this.showingHistoryForIdx = null;
        this.render();
      });
    });
    
    // Close button
    const closeBtn = this.container.querySelector('#close-history-btn');
    if (closeBtn) {
      closeBtn.onclick = () => {
        this.showingHistoryForIdx = null;
        this.render();
      };
    }
  }
  
  // Export prompts to JSON file
  exportPrompts() {
    const data = {
      folders: this.folders,
      prompts: this.prompts
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chatgpt-prompts-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  
  // Import prompts from JSON file
  importPrompts() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target.result);
          if (Array.isArray(data.folders) && Array.isArray(data.prompts)) {
            if (!confirm('This will replace your current folders and prompts. Continue?')) return;
            this.folders = data.folders;
            this.prompts = data.prompts;
            this.saveFolders();
            this.savePrompts();
            this.activeFolderId = this.folders.length ? this.folders[0].id : null;
            this.render();
            alert('Import successful!');
          } else {
            alert('Invalid file format.');
          }
        } catch (err) {
          alert('Error parsing file: ' + err.message);
        }
      };
      reader.readAsText(file);
    };
    input.click();
  }
  
  insertPrompt(text) {
    const textarea = document.querySelector('form textarea');
    if (textarea) {
      textarea.value = text;
      textarea.focus();
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }

  // Method to show the modal for adding/editing prompts
  showPromptEditorModal(promptObj, index) {
    const isEditing = promptObj !== null;
    const modalTitle = isEditing ? 'Edit Prompt' : 'Add New Prompt';

    // Define fields for the modal
    const fields = [
      { id: 'title', label: 'Prompt Title', defaultValue: promptObj?.title || '' },
      { id: 'content', label: 'Prompt Content (Markdown Supported)', type: 'textarea', defaultValue: promptObj?.content || '' },
      { id: 'tags', label: 'Tags (comma-separated)', defaultValue: (promptObj?.tags || []).join(', '), placeholder: 'e.g. brainstorming, code, writing' }
    ];

    // Create a container for the modal content
    const modalContainer = document.createElement('div');

    // Use a modified modal function or structure to handle textarea and EasyMDE
    const modalId = 'chatgpt-enhancer-prompt-editor-modal';
    document.getElementById(modalId)?.remove();

    const modalOverlay = document.createElement('div');
    modalOverlay.id = modalId;
    modalOverlay.className = 'fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4'; // Increased z-index, padding

    const modalContent = document.createElement('div');
    // Increased width, max height, and overflow for scrolling
    modalContent.className = 'bg-white dark:bg-gray-800 p-6 rounded shadow-lg w-full max-w-2xl max-h-[80vh] flex flex-col';

    modalContent.innerHTML = `<h2 class="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-200 flex-shrink-0">${modalTitle}</h2>`;

    const form = document.createElement('form');
    form.className = 'flex-grow overflow-y-auto pr-2'; // Allow form content to scroll
    const inputs = {};
    let contentTextarea;

    fields.forEach(field => {
      const label = document.createElement('label');
      label.className = 'block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300';
      label.textContent = field.label;
      form.appendChild(label);

      let input;
      if (field.type === 'textarea') {
        input = document.createElement('textarea');
        input.className = 'w-full mb-3 px-2 py-1 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 min-h-[150px]'; // Tailwind for textarea
        input.value = field.defaultValue || '';
        contentTextarea = input; // Keep reference for EasyMDE
      } else { // Default to text input
        input = document.createElement('input');
        input.type = 'text';
        input.className = 'w-full mb-3 px-2 py-1 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600'; // Tailwind for text input
        input.value = field.defaultValue || '';
        if (field.placeholder) input.placeholder = field.placeholder;
      }
      input.id = `modal-input-${field.id}`;
      form.appendChild(input);
      inputs[field.id] = input;
    });

    // Add EasyMDE to the textarea
    let easyMDEInstance = null;
    if (contentTextarea) {
      this.loadEasyMDE(() => {
        if (window.EasyMDE) {
           // Ensure previous instance is cleaned up if modal is reused quickly
           if (this._modalEasyMDE) {
             try { this._modalEasyMDE.toTextArea(); } catch(e) {}
             this._modalEasyMDE = null;
           }
           easyMDEInstance = new window.EasyMDE({
             element: contentTextarea,
             initialValue: contentTextarea.value,
             autoDownloadFontAwesome: false,
             spellChecker: false,
             status: false, // Hide status bar
             minHeight: "150px",
             // Add more toolbar options if desired
             toolbar: ["bold", "italic", "heading", "|", "quote", "unordered-list", "ordered-list", "|", "code", "link", "|", "preview", "side-by-side", "fullscreen"],
           });
           this._modalEasyMDE = easyMDEInstance; // Store instance for cleanup
        }
      });
    }

    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'flex-shrink-0 flex justify-end gap-2 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700'; // Footer styling

    const cancelButton = document.createElement('button');
    cancelButton.type = 'button';
    cancelButton.textContent = 'Cancel';
    cancelButton.className = 'px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500';
    cancelButton.onclick = () => {
       if (easyMDEInstance) { try { easyMDEInstance.toTextArea(); } catch(e){} } // Cleanup EasyMDE
       this._modalEasyMDE = null;
       modalOverlay.remove();
    };

    const okButton = document.createElement('button');
    okButton.type = 'submit';
    okButton.textContent = isEditing ? 'Save Changes' : 'Add Prompt';
    okButton.className = 'px-4 py-2 rounded bg-blue-500 text-white hover:bg-blue-600';

    buttonContainer.appendChild(cancelButton);
    buttonContainer.appendChild(okButton);

    form.onsubmit = (e) => {
      e.preventDefault();
      const newTitle = inputs['title'].value.trim();
      // Get content from EasyMDE if available, otherwise textarea
      const newContent = easyMDEInstance ? easyMDEInstance.value() : inputs['content'].value;
      const tagsInput = inputs['tags'].value;
      const newTags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);

      if (!newTitle || !newContent) {
        alert('Title and content are required.');
        return;
      }

      if (isEditing && index !== undefined && index >= 0) {
        // Editing existing prompt
        const originalPrompt = this.prompts[index];
        if (!originalPrompt.versions) originalPrompt.versions = [];
        // Save current state as a version before updating
        originalPrompt.versions.push({
          title: originalPrompt.title,
          content: originalPrompt.content,
          tags: Array.isArray(originalPrompt.tags) ? [...originalPrompt.tags] : [],
          timestamp: Date.now()
        });
        // Update prompt
        originalPrompt.title = newTitle;
        originalPrompt.content = newContent;
        originalPrompt.tags = newTags;
      } else {
        // Adding new prompt
        this.prompts.push({
          title: newTitle,
          content: newContent,
          tags: newTags,
          folderId: this.activeFolderId,
          versions: [] // Start with empty versions
        });
      }

      this.savePrompts();
      this.render(); // Re-render the main UI

      if (easyMDEInstance) { try { easyMDEInstance.toTextArea(); } catch(e){} } // Cleanup EasyMDE
      this._modalEasyMDE = null;
      modalOverlay.remove();
    };

    modalContent.appendChild(form);
    modalContent.appendChild(buttonContainer); // Add buttons after the form
    modalOverlay.appendChild(modalContent);
    document.body.appendChild(modalOverlay);

    // Focus the title input
    inputs['title']?.focus();
  }
}

// SidebarManager class for chat organization
class SidebarManager {
  constructor() {
    this.sidebar = null;
    this.observer = new MutationObserver(this.initSidebar.bind(this));
    this.observeSidebar();
  }

  observeSidebar() {
    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  initSidebar() {
    const sidebar = document.querySelector('nav');
    if (!sidebar || this.sidebar === sidebar) return;
    
    this.sidebar = sidebar;
    this.injectFolderSection();
  }

  injectFolderSection() {
    // Create folders section
    const section = document.createElement('div');
    section.className = 'chat-folders-section';
    section.innerHTML = `
      <div class="flex items-center justify-between p-2 border-b">
        <h3 class="font-semibold">Chat Folders</h3>
        <div class="flex space-x-2">
          <button class="add-folder text-gray-500 hover:text-gray-700" title="Add Folder">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
            </svg>
          </button>
          <button class="toggle-folders text-gray-500 hover:text-gray-700">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
            </svg>
          </button>
        </div>
      </div>
      <div class="folder-list p-2 space-y-1"></div>
    `;

    // Insert after existing chats
    const chatsSection = this.sidebar.querySelector('div:first-child');
    if (chatsSection) {
      chatsSection.after(section);
    }

    // Add event listeners
    section.querySelector('.toggle-folders').addEventListener('click', () => {
      section.querySelector('.folder-list').classList.toggle('hidden');
    });

    section.querySelector('.add-folder').addEventListener('click', () => {
      this.showAddFolderModal();
    });

    this.setupDragAndDrop();
  }

  showAddFolderModal() {
    showCustomModal('Add Folder', [
      { id: 'name', label: 'Folder Name' },
      { id: 'color', label: 'Color', type: 'color', defaultValue: '#60a5fa' }
    ], (result) => {
      if (result.name) {
        this.addFolder({
          id: Date.now().toString(),
          name: result.name,
          color: result.color,
          chats: []
        });
      }
    });
  }

  addFolder(folder) {
    const folderList = this.sidebar.querySelector('.folder-list');
    if (!folderList) return;

    const folderEl = document.createElement('div');
    folderEl.className = 'folder-item';
    folderEl.dataset.id = folder.id;
    folderEl.innerHTML = `
      <span class="drag-handle">☰</span>
      <span class="name" style="color:${folder.color}">${folder.name}</span>
      <span class="count">0</span>
    `;

    folderList.appendChild(folderEl);
    this.setupFolderEvents(folderEl);
  }

  setupFolderEvents(folderEl) {
    folderEl.addEventListener('click', () => {
      document.querySelectorAll('.folder-item').forEach(el => {
        el.classList.remove('active');
      });
      folderEl.classList.add('active');
    });

    folderEl.querySelector('.drag-handle').addEventListener('mousedown', (e) => {
      e.preventDefault(); // Prevent text selection
    });
  }

  setupDragAndDrop() {
    const folderList = this.sidebar.querySelector('.folder-list');
    if (!folderList) return;

    folderList.addEventListener('dragover', (e) => {
      e.preventDefault();
      const afterElement = this.getDragAfterElement(folderList, e.clientY);
      const draggable = document.querySelector('.dragging');
      
      if (afterElement == null) {
        folderList.appendChild(draggable);
      } else {
        folderList.insertBefore(draggable, afterElement);
      }
    });

    document.querySelectorAll('.folder-item').forEach(item => {
      item.addEventListener('dragstart', () => {
        item.classList.add('dragging');
      });

      item.addEventListener('dragend', () => {
        item.classList.remove('dragging');
      });
    });
  }

  getDragAfterElement(container, y) {
    const draggableElements = [...container.querySelectorAll('.folder-item:not(.dragging)')];

    return draggableElements.reduce((closest, child) => {
      const box = child.getBoundingClientRect();
      const offset = y - box.top - box.height / 2;
      
      if (offset < 0 && offset > closest.offset) {
        return { offset: offset, element: child };
      } else {
        return closest;
      }
    }, { offset: Number.NEGATIVE_INFINITY }).element;
  }
}

// OverlayPanel class definition
class OverlayPanel {
  constructor(container) {
    this.container = container;
    this.promptManager = null;
    this.render();
  }

  render() {
    this.container.innerHTML = `
      <div id="chatgpt-enhancer-header" class="flex justify-between items-center p-3 border-b border-gray-300 dark:border-gray-700" style="cursor: move;">
        <h2 class="font-semibold text-gray-800 dark:text-gray-200">ChatGPT Enhancer</h2>
        <button id="chatgpt-enhancer-close-btn" class="text-gray-500 hover:text-gray-800 dark:hover:text-gray-100">&times;</button>
      </div>
      
      <div class="flex border-b border-gray-300 dark:border-gray-700">
        <button data-tab="prompts" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400">Prompts</button>
        <button data-tab="chats" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">Chats</button>
        <button data-tab="gpts" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">GPTs</button>
        <button data-tab="settings" class="tab-btn flex-1 p-2 text-sm font-medium text-center text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200">Settings</button>
      </div>

      <div id="tab-content" class="p-3">
        <div data-tab-content="prompts" class="tab-pane">
          <div id="prompt-manager-container"></div>
        </div>
        <div data-tab-content="chats" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">Chat organization coming soon...</p>
        </div>
        <div data-tab-content="gpts" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">CustomGPT management coming soon...</p>
        </div>
        <div data-tab-content="settings" class="tab-pane hidden">
          <p class="text-sm text-gray-600 dark:text-gray-300">Settings coming soon...</p>
        </div>
      </div>
    `;

    this.addEventListeners();
  }

  addEventListeners() {
    // Close button
    this.container.querySelector('#chatgpt-enhancer-close-btn').onclick = () => {
      this.container.classList.add('hidden');
    };

    // Tab switching
    const tabButtons = this.container.querySelectorAll('.tab-btn');
    const tabPanes = this.container.querySelectorAll('.tab-pane');

    tabButtons.forEach(button => {
      button.addEventListener('click', () => {
        const targetTab = button.dataset.tab;

        // Update button styles
        tabButtons.forEach(btn => {
          btn.classList.remove('text-blue-600', 'dark:text-blue-400', 'border-blue-600', 'dark:border-blue-400');
          btn.classList.add('text-gray-500', 'dark:text-gray-400');
        });
        button.classList.add('text-blue-600', 'dark:text-blue-400', 'border-blue-600', 'dark:border-blue-400');
        button.classList.remove('text-gray-500', 'dark:text-gray-400');

        // Update pane visibility
        tabPanes.forEach(pane => {
          if (pane.dataset.tabContent === targetTab) {
            pane.classList.remove('hidden');
            // Initialize PromptManager when Prompts tab is shown
            if (targetTab === 'prompts' && !this.promptManager) {
              const container = pane.querySelector('#prompt-manager-container');
              this.promptManager = new PromptManager(container);
            }
          } else {
            pane.classList.add('hidden');
          }
        });
      });
    });
  }
}

// Method to show the modal for adding/editing prompts
showPromptEditorModal(promptObj, index); { // Added semicolon
  const isEditing = promptObj !== null;
  const modalTitle = isEditing ? 'Edit Prompt' : 'Add New Prompt';

  // Define fields for the modal
  const fields = [
    { id: 'title', label: 'Prompt Title', defaultValue: promptObj?.title || '' },
    { id: 'content', label: 'Prompt Content (Markdown Supported)', type: 'textarea', defaultValue: promptObj?.content || '' },
    { id: 'tags', label: 'Tags (comma-separated)', defaultValue: (promptObj?.tags || []).join(', '), placeholder: 'e.g. brainstorming, code, writing' }
  ];

  // Create a container for the modal content
  const modalContainer = document.createElement('div');

  // Use a modified modal function or structure to handle textarea and EasyMDE
  const modalId = 'chatgpt-enhancer-prompt-editor-modal';
  document.getElementById(modalId)?.remove();

  const modalOverlay = document.createElement('div');
  modalOverlay.id = modalId;
  modalOverlay.className = 'fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4'; // Increased z-index, padding

  const modalContent = document.createElement('div');
  // Increased width, max height, and overflow for scrolling
  modalContent.className = 'bg-white dark:bg-gray-800 p-6 rounded shadow-lg w-full max-w-2xl max-h-[80vh] flex flex-col';

  modalContent.innerHTML = `<h2 class="text-xl font-semibold mb-4 text-gray-800 dark:text-gray-200 flex-shrink-0">${modalTitle}</h2>`;

  const form = document.createElement('form');
  form.className = 'flex-grow overflow-y-auto pr-2'; // Allow form content to scroll
  const inputs = {};
  let contentTextarea;

  fields.forEach(field => {
    const label = document.createElement('label');
    label.className = 'block mb-1 text-sm font-medium text-gray-700 dark:text-gray-300';
    label.textContent = field.label;
    form.appendChild(label);

    let input;
    if (field.type === 'textarea') {
      input = document.createElement('textarea');
      input.className = 'w-full mb-3 px-2 py-1 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 min-h-[150px]'; // Tailwind for textarea
      input.value = field.defaultValue || '';
      contentTextarea = input; // Keep reference for EasyMDE
    } else { // Default to text input
      input = document.createElement('input');
      input.type = 'text';
      input.className = 'w-full mb-3 px-2 py-1 border rounded dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600'; // Tailwind for text input
      input.value = field.defaultValue || '';
      if (field.placeholder) input.placeholder = field.placeholder;
    }
    input.id = `modal-input-${field.id}`;
    form.appendChild(input);
    inputs[field.id] = input;
  });

  // Add EasyMDE to the textarea
  let easyMDEInstance = null;
  if (contentTextarea) {
    this.loadEasyMDE(() => {
      if (window.EasyMDE) {
         // Ensure previous instance is cleaned up if modal is reused quickly
         if (this._modalEasyMDE) {
           try { this._modalEasyMDE.toTextArea(); } catch(e) {}
           this._modalEasyMDE = null;
         }
         easyMDEInstance = new window.EasyMDE({
           element: contentTextarea,
           initialValue: contentTextarea.value,
           autoDownloadFontAwesome: false,
           spellChecker: false,
           status: false, // Hide status bar
           minHeight: "150px",
           // Add more toolbar options if desired
           toolbar: ["bold", "italic", "heading", "|", "quote", "unordered-list", "ordered-list", "|", "code", "link", "|", "preview", "side-by-side", "fullscreen"],
         });
         this._modalEasyMDE = easyMDEInstance; // Store instance for cleanup
      }
    });
  }

  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'flex-shrink-0 flex justify-end gap-2 mt-4 pt-4 border-t border-gray-200 dark:border-gray-700'; // Footer styling

  const cancelButton = document.createElement('button');
  cancelButton.type = 'button';
  cancelButton.textContent = 'Cancel';
  cancelButton.className = 'px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 dark:bg-gray-600 dark:hover:bg-gray-500';
  cancelButton.onclick = () => {
     if (easyMDEInstance) { try { easyMDEInstance.toTextArea(); } catch(e){} } // Cleanup EasyMDE
     this._modalEasyMDE = null;
     modalOverlay.remove();
  };

  const okButton = document.createElement('button');
  okButton.type = 'submit';
  okButton.textContent = isEditing ? 'Save Changes' : 'Add Prompt';
  okButton.className = 'px-4 py-2 rounded bg-blue-500 text-white hover:bg-blue-600';

  buttonContainer.appendChild(cancelButton);
  buttonContainer.appendChild(okButton);

  form.onsubmit = (e) => {
    e.preventDefault();
    const newTitle = inputs['title'].value.trim();
    // Get content from EasyMDE if available, otherwise textarea
    const newContent = easyMDEInstance ? easyMDEInstance.value() : inputs['content'].value;
    const tagsInput = inputs['tags'].value;
    const newTags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);

    if (!newTitle || !newContent) {
      alert('Title and content are required.');
      return;
    }

    if (isEditing && index !== undefined && index >= 0) {
      // Editing existing prompt
      const originalPrompt = this.prompts[index];
      if (!originalPrompt.versions) originalPrompt.versions = [];
      // Save current state as a version before updating
      originalPrompt.versions.push({
        title: originalPrompt.title,
        content: originalPrompt.content,
        tags: Array.isArray(originalPrompt.tags) ? [...originalPrompt.tags] : [],
        timestamp: Date.now()
      });
      // Update prompt
      originalPrompt.title = newTitle;
      originalPrompt.content = newContent;
      originalPrompt.tags = newTags;
    } else {
      // Adding new prompt
      this.prompts.push({
        title: newTitle,
        content: newContent,
        tags: newTags,
        folderId: this.activeFolderId,
        versions: [] // Start with empty versions
      });
    }

    this.savePrompts();
    this.render(); // Re-render the main UI

    if (easyMDEInstance) { try { easyMDEInstance.toTextArea(); } catch(e){} } // Cleanup EasyMDE
    this._modalEasyMDE = null;
    modalOverlay.remove();
  };

  modalContent.appendChild(form);
  modalContent.appendChild(buttonContainer); // Add buttons after the form
  modalOverlay.appendChild(modalContent);
  document.body.appendChild(modalOverlay);

  // Focus the title input
  inputs['title']?.focus();
}

// Create overlay panel and toggle button
function createOverlayAndButton() {
  const overlayId = 'chatgpt-enhancer-overlay';
  const toggleBtnId = 'chatgpt-enhancer-toggle-btn';

  // Remove existing if any
  document.getElementById(overlayId)?.remove();
  document.getElementById(toggleBtnId)?.remove();

  // Create overlay panel container
  const overlay = document.createElement('div');
  overlay.id = overlayId;
  overlay.className = 'fixed h-full w-80 max-w-full bg-white dark:bg-gray-900 shadow-lg border border-gray-300 dark:border-gray-700 hidden overflow-y-auto transition-transform duration-300';
  
  // Apply important styles
  const applyImportantStyle = (element, prop, value) => {
    element.style.setProperty(prop, value, 'important');
  };
  
  // Set position and styling
  applyImportantStyle(overlay, 'position', 'fixed');
  applyImportantStyle(overlay, 'top', '100px');
  applyImportantStyle(overlay, 'left', 'calc(100% - 350px)');
  applyImportantStyle(overlay, 'z-index', '10000');
  applyImportantStyle(overlay, 'cursor', 'default');
  applyImportantStyle(overlay, 'user-select', 'none');
  applyImportantStyle(overlay, 'pointer-events', 'auto');
  
  // Instantiate OverlayPanel
  new OverlayPanel(overlay);
  document.body.appendChild(overlay);
  
  // Create floating toggle button
  const toggleBtn = document.createElement('button');
  toggleBtn.id = toggleBtnId;
  toggleBtn.innerHTML = '&#9881;';
  toggleBtn.title = 'Open ChatGPT Enhancer (Drag to reposition)';
  toggleBtn.className = 'p-2 rounded bg-blue-500 hover:bg-blue-600 text-white shadow-lg transition-all duration-300';
  
  // Apply button styles
  applyImportantStyle(toggleBtn, 'position', 'fixed');
  applyImportantStyle(toggleBtn, 'z-index', '10000');
  applyImportantStyle(toggleBtn, 'cursor', 'pointer');
  
  // Set button position
  const storedBtnLeft = localStorage.getItem('chatgpt-enhancer-btn-left');
  const storedBtnTop = localStorage.getItem('chatgpt-enhancer-btn-top');
  
  if (storedBtnLeft && storedBtnTop) {
    applyImportantStyle(toggleBtn, 'left', storedBtnLeft);
    applyImportantStyle(toggleBtn, 'top', storedBtnTop);
  } else {
    applyImportantStyle(toggleBtn, 'top', '50%');
    applyImportantStyle(toggleBtn, 'right', '0');
    applyImportantStyle(toggleBtn, 'transform', 'translateY(-50%)');
  }
  
  // Add button event listeners
  toggleBtn.addEventListener('click', (e) => {
    if (toggleBtn.getAttribute('data-dragging') !== 'true') {
      overlay.classList.toggle('hidden');
    }
  });
  
  // Add drag handlers
  const btnDragHandlers = {
    dragStart: function(e) {
      toggleBtn.setAttribute('data-dragging', 'true');
      const rect = toggleBtn.getBoundingClientRect();
      toggleBtn.dataset.dragOffsetX = e.clientX - rect.left;
      toggleBtn.dataset.dragOffsetY = e.clientY - rect.top;
      toggleBtn.style.opacity = '0.8';
      e.preventDefault();
    },
    
    dragMove: function(e) {
      if (toggleBtn.getAttribute('data-dragging') !== 'true') return;
      const offsetX = parseFloat(toggleBtn.dataset.dragOffsetX) || 0;
      const offsetY = parseFloat(toggleBtn.dataset.dragOffsetY) || 0;
      applyImportantStyle(toggleBtn, 'left', (e.clientX - offsetX) + 'px');
      applyImportantStyle(toggleBtn, 'top', (e.clientY - offsetY) + 'px');
      toggleBtn.style.removeProperty('right');
      toggleBtn.style.removeProperty('transform');
      e.preventDefault();
    },
    
    dragEnd: function(e) {
      if (toggleBtn.getAttribute('data-dragging') !== 'true') return;
      localStorage.setItem('chatgpt-enhancer-btn-left', toggleBtn.style.left);
      localStorage.setItem('chatgpt-enhancer-btn-top', toggleBtn.style.top);
      toggleBtn.removeAttribute('data-dragging');
      toggleBtn.style.opacity = '1';
      delete toggleBtn.dataset.dragOffsetX;
      delete toggleBtn.dataset.dragOffsetY;
      e.preventDefault();
    }
  };
  
  // Add mouse and pointer events
  toggleBtn.addEventListener('mousedown', btnDragHandlers.dragStart);
  document.addEventListener('mousemove', btnDragHandlers.dragMove);
  document.addEventListener('mouseup', btnDragHandlers.dragEnd);
  toggleBtn.addEventListener('pointerdown', btnDragHandlers.dragStart);
  document.addEventListener('pointermove', btnDragHandlers.dragMove);
  document.addEventListener('pointerup', btnDragHandlers.dragEnd);
  
  document.body.appendChild(toggleBtn);
}

// Initial create
createOverlayAndButton();

// Update persistent observer
const overlayObserver = new MutationObserver(() => {
  if (!document.getElementById('chatgpt-enhancer-overlay') ||
      !document.getElementById('chatgpt-enhancer-toggle-btn')) {
    console.log('Re-injecting overlay panel and toggle button');
    createOverlayAndButton();
  }
});
overlayObserver.observe(document.body, { childList: true, subtree: true });