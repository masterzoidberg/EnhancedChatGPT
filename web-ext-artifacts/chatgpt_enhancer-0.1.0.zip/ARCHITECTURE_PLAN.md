# ChatGPT Enhancer Chrome Extension — Updated Architecture Plan

---

## Overview

A **standalone Chrome extension** (Manifest V3) that enhances ChatGPT with:

- **Unified overlay panel** for:
  - **Prompt Management**
  - **Chat Organization**
  - **CustomGPT Management**
  - **Settings**
- **Quick Access Bar** above input box for fast prompt insertion
  - **Customizable:** Users can add/remove/edit quick prompts (future: edit in a dedicated quick launch area)
- **Chat Minimap** for fast navigation in long conversations
- **Minimalist UI** inspired by ChatGPT, styled with TailwindCSS
- **Local data storage** (IndexedDB + chrome.storage)
- **Built in JavaScript**

---

## UI/UX Design

### 1. **Floating Button**

- Fixed on the **right edge** of the ChatGPT window
- Minimal icon (e.g., ⚡ ➕)
- **Click toggles** the overlay panel open/close

### 2. **Unified Overlay Panel**

- **Slide-in panel** from the right or modal overlay
- **Tabbed interface** with:

| Tab          | Features                                                                                   |
|--------------|--------------------------------------------------------------------------------------------|
| **Prompts**  | Folder management, prompt CRUD, drag/drop, versioning, tagging, import/export             |
| **Chats**    | Chat folder management, drag/drop chats, rename, reorder, timestamps, import/export       |
| **CustomGPTs** | Collapse/expand, hide/group, organize saved GPTs                                         |
| **Settings** | Light/dark mode toggle, JSON import/export, other preferences                             |

- **Close button** to hide overlay

### 3. **Quick Access Bar**

- Small horizontal bar **above ChatGPT input box**
- Shows **favorite or recent prompts**
- **One-click insert** into input
- **Add/remove/edit quick prompts** (future: edit in a dedicated quick launch area)
- Minimal footprint

### 4. **Chat Minimap**

- **Vertical scrollable bar** on the side of the chat window
- Tiny blocks representing each message
- **Hover** shows message snippet
- **Click** scrolls to that message
- **Highlights** search hits, bookmarks, or important points
- **Collapsible** when not needed

---

## Project Structure

```
chatgpt-enhancer-extension/
│
├── manifest.json
├── background.js
├── content/
│   ├── contentScript.js
│   ├── contentStyle.css
│   └── ui/
│       ├── OverlayPanel.js
│       ├── QuickAccessBar.js
│       ├── ChatMinimap.js
│       ├── storage.js
│       └── components/
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
├── icons/
│   └── icon16.png, icon48.png, icon128.png
├── tailwind.config.js
├── package.json
└── README.md
```

---

## Core Features

- **Floating toggle button** to open/close overlay
- **Overlay panel** with tabs for Prompts, Chats, CustomGPTs, Settings
- **Prompt management**: folders, prompts, drag/drop, versioning, tagging
- **Chat organization**: folders, drag/drop chats, rename, timestamps
- **CustomGPT management**: collapse, group, hide
- **Quick access bar** for fast prompt insertion (add/remove/edit quick prompts, future: edit in quick launch area)
- **Chat minimap** for fast navigation in long chats
- **Local storage** with IndexedDB + chrome.storage
- **JSON import/export**
- **Light/dark mode toggle**

---

## Data Model (Simplified)

```mermaid
classDiagram
    class Folder {
        id: string
        name: string
        color: string
        order: number
        type: "prompt" | "chat"
    }
    class Prompt {
        id: string
        folderId: string
        title: string
        content: string
        tags: string[]
        versions: PromptVersion[]
        order: number
    }
    class PromptVersion {
        timestamp: number
        content: string
    }
    class Chat {
        id: string
        folderId: string
        title: string
        timestamp: number
        order: number
    }

    Folder <|-- Prompt
    Folder <|-- Chat
    Prompt "1" *-- "*" PromptVersion
```

---

## Development Phases

1. **Setup**
   - Manifest, Tailwind, content script
2. **Floating Button + Overlay Panel**
   - Toggle button
   - Overlay with tabs
3. **Prompt Management Tab**
   - Folder + prompt CRUD, drag/drop, versioning, tagging
4. **Chat Organization Tab**
   - Folder + chat CRUD, drag/drop
5. **CustomGPT Management Tab**
   - Collapse, group, hide
6. **Quick Access Bar**
   - Favorite/recent prompts, insert, add/remove/edit quick prompts (future: edit in quick launch area)
7. **Chat Minimap**
   - Scrollable overview, jump navigation
8. **Settings Tab**
   - Import/export, theme toggle
9. **Data Storage**
   - IndexedDB + chrome.storage
10. **Polish**
    - Animations, responsive, testing

---

## Summary

- **Unified overlay panel** with tabs for all management features
- **Quick access bar** for fast prompt insertion (add/remove/edit quick prompts, future: edit in quick launch area)
- **Chat minimap** for easy navigation in long conversations
- **Minimalist, ChatGPT-inspired UI**
- **Local storage only**
- **All core + nice-to-have features included**