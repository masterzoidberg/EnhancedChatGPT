// popup.js - ChatGPT Enhancer Extension Popup

document.getElementById('importBtn').addEventListener('click', () => {
  console.log('Import JSON clicked');
  // TODO: Implement JSON import
});

document.getElementById('exportBtn').addEventListener('click', () => {
  console.log('Export JSON clicked');
  // TODO: Implement JSON export
});

document.getElementById('toggleThemeBtn').addEventListener('click', () => {
  console.log('Toggle Light/Dark mode clicked');
  // TODO: Implement theme toggle
});