// background.js - ChatGPT Enhancer Extension Service Worker

// Initialize local storage
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed - initializing storage');
  chrome.storage.local.get(['prompts', 'folders'], (result) => {
    if (!result.prompts) {
      chrome.storage.local.set({ prompts: [] });
    }
    if (!result.folders) {
      chrome.storage.local.set({ folders: [] });
    }
  });
});

// Context menu for quick actions
chrome.contextMenus.create({
  id: 'insertPrompt',
  title: 'Insert Prompt',
  contexts: ['editable']
});

// Message handling
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'SAVE_PROMPT') {
    chrome.storage.local.get(['prompts'], (result) => {
      const prompts = result.prompts || [];
      prompts.push(request.prompt);
      chrome.storage.local.set({ prompts }, () => {
        sendResponse({status: 'success'});
      });
    });
    return true; // Keep message channel open
  }
  
  if (request.type === 'GET_PROMPTS') {
    chrome.storage.local.get(['prompts'], (result) => {
      sendResponse(result.prompts || []);
    });
    return true;
  }
});

console.log('Background script loaded successfully');